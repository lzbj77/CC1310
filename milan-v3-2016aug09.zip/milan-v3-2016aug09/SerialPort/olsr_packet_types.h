#ifndef _OLSR_PKT_TYPES
#define _OLSR_PKT_TYPES

typedef signed char INT8;
typedef unsigned char UINT8;
typedef short INT16;
typedef unsigned short UINT16;
typedef signed int INT32;
typedef unsigned int UINT32;


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#include <winsock2.h>

#define INVALID            -1
//link types
#define UNSPEC_LINK        0x00
#define ASYM_LINK          0x01
#define SYM_LINK           0x02
#define LOST_LINK          0x03
//neighbor types
#define NOT_NEIGH          0x00
#define SYM_NEIGH          0x01
#define MPR_NEIGH          0x02
//version 4 link types which are combinations of version 8 types.  is version 8 compliant.
#define SYM_LINKv4         0x06 
#define ASYM_LINKv4        0x01
#define MPR_LINKv4         0x0a
#define LOST_LINKv4        0x03
#define PENDING_LINK       0x05 //not really valid

#define NRLOLSR_HELLO      0x01
#define NRLOLSR_TC_MESSAGE 0x02
#define NRLOLSR_HNA_MESSAGE 0x4

#define NRLOLSR_TC_MESSAGE_EXTRA 0xF1

#define WILL_NEVER         0x00
#define WILL_LOW           0x01
#define WILL_DEFAULT       0x03
#define WILL_HIGH          0x06
#define WILL_ALWAYS        0x07

#define TIME_CONSTANT      .0625 //C value as described in v8 olsr spec 


struct ListNode
{
  ListNode *next, *prev;
  char* object;
  int size;
};

class List_
{
 public:
  //  static int ccounter, dcounter, counter;
  ListNode *head, *tail, *peekptr;
  ~List_(){destroy();}//fprintf(stdout,"%d is count %d is ccount %d is dcount %d is combined number\n",--counter,ccounter,++dcounter,ccounter-dcounter);}
  List_(){head=NULL;tail=NULL;peekptr=NULL;}//;fprintf(stdout,"d is count %d is ccount %d is dcount %d is combinednumber \n",++counter,++ccounter,dcounter,ccounter-dcounter);}
  bool IsEmpty() {if(head) return 0; return 1;}
  //List(List &); //copy constructor;
  bool append(char* object,int size);
  bool destroy();
  int pack(char* buffer,int maxSize);  //returns size that is used;
  char* peekNext(int* sizeptr); //sets pointer to next object (no copy is made)
  void peekInit(){peekptr=NULL;}
};

class LinkMessage
{
 public:
  LinkMessage(){linkCode=0;reserved=0;size=4;}
  ~LinkMessage(){}//neighbors.destroy();}
  UINT8 linkCode;           // SYM, ASYM, MRP, LOST or PENDING
  UINT8 reserved;           // 1 if <degrees> is used, 0 otherwise
  UINT16 size;              // Link message size
  List_ neighbors;          // Links
  List_ degrees; //degrees of neighbors reserved is set to 1 if this list is used.
  bool addNeighbor(UINT32 newNeighbor);
  bool addNeighborExtra(UINT32 newNeighbor, unsigned long degree);//used for sending 2 hop degree information to do ECDS for manet OSPF extentions
  int pack(char* buffer,int maxSize); //returns size that is used;
  int unpack(char* buffer,int maxSize); //returns size that was used, buffer can extend past one LinkMessage
};

class HelloMessage 
{
 public:
  HelloMessage(){reserved1=0;htime=0;willingness=WILL_DEFAULT;size=4;}
  ~HelloMessage(){}//messages.destroy();}
  UINT16 size;  //variable not placed in packet
  UINT16 reserved1;         // Set to 0x0000
  UINT8 htime;              // HELLO emission interval
  UINT8 willingness;        // Willingnes to be an MPR
  List_ messages;           // Neighbors
  //  bool addInterface(UINT32 *newInterface);
  bool addLinkMessage(LinkMessage *newMessage);
  int pack(char* buffer,int maxSize);
  int unpack(char* buffer,int maxSize); //returns size that was used
};

class OlsrMessage
{
 public:
  OlsrMessage(){type=0;Vtime=0;size=8;ttl=0;hopc=0;D_seq_num=0;message=NULL;} //size does not account for size of O_addr use SetO_addr function
  ~OlsrMessage(){free(message);}
  UINT8 type;       // HELLO, TC e.t.c.
  UINT8 Vtime;      // Valid time, after which this info must be deleted (if not updated by other messages
  UINT16 size;      // Message size in bytes
  UINT32 O_addr;    // Originator address
  UINT8 ttl;        // Time to live, maximum number of hops this message can travel
  UINT8 hopc;       // Hop count, the number of hops this message has traveled
  UINT16 D_seq_num; // Message sequence number

  char *message;
  bool SetO_addr(const UINT32 &theO_addr);

  bool setHelloMessage(HelloMessage* theHello); 

  
  int pack(char* buffer, int maxSize);
  int unpack(char* buffer, int maxSize); //returns size that was used
};

class OlsrPacket
{
 public:
  OlsrPacket(){size=4;seqno=0;}
  ~OlsrPacket(){}//messages.destroy();}
  UINT16 size;      // Packet size
  UINT16 seqno;     // Packet sequence number
  List_ messages;   // Messages in this packet
  bool addOlsrMessage(OlsrMessage *newMessage);
  int pack(char* buffer,int maxSize);
  int unpack(char* buffer, int maxSize); //returns size that was used
  void clear();
};

#endif // _OLSR_PKT_TYPES

