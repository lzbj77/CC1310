#ifndef UDPSOCKETHANDLER_H
#define UDPSOCKETHANDLER_H

#include <QObject>
#include <QUdpSocket>
#include "olsr_packet_types.h"

class UdpSocketHandler : public QObject
{
    Q_OBJECT
public:
    explicit UdpSocketHandler(QObject *parent = 0);
    ~UdpSocketHandler();

    bool SendData(const QByteArray &data);

signals:
    void RoutingPacketArrived(QByteArray &olsrPacket);

public slots:
    void ReadData();

private:

    void PrintPacket(QHostAddress &address, quint16 port, QByteArray &data);

    QUdpSocket *m_socket;
    QByteArray m_writeData;
};

#endif // UDPSOCKETHANDLER_H
