#ifndef TIMERMANAGER_H
#define TIMERMANAGER_H

#include <QObject>
#include <QTimer>

class TimerManager : public QObject
{
    Q_OBJECT
public:
    explicit TimerManager(int hello_interval, int rand_value, QObject *parent = 0);
    ~TimerManager();

    QTimer hello_timer;
    QTimer hello_jitter_timer;

signals:

public slots:
    void Stop();
    void Start(double rand_value);

private:

};

#endif // TIMERMANAGER_H
