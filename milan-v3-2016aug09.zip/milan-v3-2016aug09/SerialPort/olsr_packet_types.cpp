#include "olsr_packet_types.h"
#include "QDebug"

//OlsrPacket stuff
//int books=0;
bool
OlsrPacket::addOlsrMessage(OlsrMessage *newMessage){
  size+=newMessage->size;
  
  char* rawMessage = new char[newMessage->size];
  //void* rawMessage=malloc(newMessage->size);
  
  if(!rawMessage){
    fprintf(stderr,"malloc returned null pointer in OlsrPacket::addOlsrMessage\n");
    return 0;
  }
  newMessage->pack((char*)rawMessage,newMessage->size);
  int returnvalue = messages.append(rawMessage,newMessage->size);
  
  delete[] rawMessage;
  //free(rawMessage);
  
  if(returnvalue > 0)
	return true;
  return false;
}
int 
OlsrPacket::pack(char* buffer,int maxSize){
  int sizeused=4;
  ((UINT16*)buffer)[0]=size;
  ((UINT16*)buffer)[1]=seqno;
  sizeused += messages.pack(&buffer[4],maxSize-sizeused);
  if(sizeused<4){
    fprintf(stderr,"OlsrPacket::pack error packing olsr messages,%d is my maxSize, %d is my sizeused\n",maxSize,sizeused);
    return -1;
  }
  return sizeused;
}
int 
OlsrPacket::unpack(char* buffer,int maxSize){
  int sizeused = 4;
  size=((UINT16*)buffer)[0];
  seqno=((UINT16*)buffer)[1];
  qDebug() << "Packet size: " << size << ", Packet seqno: " << seqno << '\n';
  if(size>maxSize){
    fprintf(stderr,"OlsrPacket::unpack packet size %d is greater than maxSize %d!\n",size,maxSize);
  }
  OlsrMessage newmessage;
  sizeused+=newmessage.unpack(&buffer[4],size-4);
  addOlsrMessage(&newmessage);
  if(sizeused>maxSize){
    fprintf(stderr,"OlsrPacket::unpack sizeused %d is greater than maxSize %d!\n",sizeused,maxSize);
  }
  fprintf(stdout,"added first olsr message\n");
  size=((UINT16*)buffer)[0];//needed to reset the size value as addolsrmessage adds to the size variable
  //new code
  //while(sizeused<maxSize){
  while(sizeused<size){ //changed line to allow for padding in olsr messages 
    fprintf(stdout,"trying to add second message to packet in unpack sizeused=%d size=%d maxsize=%d\n",sizeused,size,maxSize);
    sizeused+=newmessage.unpack(&buffer[sizeused],size-sizeused);
    fprintf(stdout,"after unpack sizeused=%d size=%d maxsize=%d testvalue=%d\n",sizeused,size,maxSize,((UINT16*)buffer)[0]);
    addOlsrMessage(&newmessage);
    //we need to correct size value as addOlsrMessage adds the size of the message to the size variable 
    size=((UINT16*)buffer)[0];
    fprintf(stdout,"after add message sizeused=%d size=%d maxsize=%d testvalue=%d\n",sizeused,size,maxSize,((UINT16*)buffer)[0]);
    if(sizeused>maxSize){
      fprintf(stderr,"OlsrPacket::unpack sizeused %d is greater than maxSize %d!\n",sizeused,maxSize);
    }
    fprintf(stdout,"added olsr message to packet in unpack success sizeused=%d size=%d maxsize=%d testvalue=%d\n",sizeused,size,maxSize,((UINT16*)buffer)[0]);
  }
  //end new code
  if(sizeused!=size){
    fprintf(stderr,"OlsrPacket::unpack sizeused %d is not equal to packet size value %d! \n",sizeused,size);
  }
  
  return size;
}
void 
OlsrPacket::clear(){
  messages.destroy();
  size=4;
  seqno=0;
}

//OlsrMessage stuff
bool
OlsrMessage::setHelloMessage(HelloMessage* theHello){
  size+=theHello->size;
  //hello=theHello;
  if(message){ 
    fprintf(stderr,"message has value while in OlsrMessage::setHelloMessage double check pointers\n");
    return 0;
  }

  //message = (char*)malloc(theHello->size);
  message = new char[theHello->size];

  if(!message){ 
    fprintf(stderr,"malloc returned NULL in Olsrmessage::setHelloMessage\n"); 
    return 0;
  }
  theHello->pack(message,theHello->size);
  return 1;
}

bool
OlsrMessage::SetO_addr(const UINT32 &theO_addr){
  /*  if(O_addr.IsValid()){
    if(O_addr.Type()==IPv4){
      size-=4;
    } else if(O_addr.Type()==IPv6){
      size-=16;
    }
    }*/
  O_addr = theO_addr;
  size+=4;

  return true;
}
int
OlsrMessage::pack(char* buffer, int maxSize){
    ((UINT8*)buffer)[0]=type;
    ((UINT8*)buffer)[1]=Vtime;
    ((UINT16*)buffer)[1]=size;
    ((UINT32*)buffer)[1]=O_addr;
    ((UINT8*)buffer)[8]=ttl;
    ((UINT8*)buffer)[9]=hopc;
    ((UINT16*)buffer)[5]=D_seq_num;
    memmove(buffer+12,message,size-12);

  return size;
}
int
OlsrMessage::unpack(char* buffer, int maxSize){
    type=(UINT8)buffer[0];
    Vtime=(UINT8)buffer[1];
    size=((UINT16*)buffer)[1];
    memmove(&O_addr,buffer+4,4);
    qDebug() << "Message type: " << type << ", Message Vtime: " << Vtime << "Message orig_addr: " << O_addr << '\n';
    ttl=(UINT8)buffer[8];
//    qDebug() << "Message ttl: " << ttl << '\n';
    hopc=(UINT8)buffer[9];
//    qDebug() << "Message hopcount: " << hopc << '\n';
    D_seq_num=((UINT16*)buffer)[5];
//    qDebug() << "Message seq_num: " << D_seq_num << '\n';
 
    //fprintf(stdout,"%d type,%d Vtime,%d size,%s o_addr,%d ttl,%d hopc, %d seqnum\n",type,Vtime,size,O_addr.GetHostString(),ttl,hopc,D_seq_num);

    //message = (char*)malloc(size-12);
    message = new char[size-12];

    if(message){
      memmove(message,buffer+12,size-12);
    } else {
      fprintf(stderr,"OlsrMessage::unpack malloc returned NULL!\n");
      return 0;
    }
    //  if(sizeused>maxSize){
    //  fprintf(stderr,"OlsrMessage::unpack:: sizeused %d is greater than the maxSize %d allowed!\n",sizeused,maxSize);
    // }
    //if(sizeused!=size){
    //  fprintf(stderr,"OlsrMessage::unpack:: sizeused %d is different than what packet size %d value is!\n",sizeused,size); 
    //}

  fprintf(stdout,"returning from olsrmessage unpack size=%d\n",size);
  return size;
}
//end OlsrMessage class


//helloMessage stuff
//bool
//HelloMessage::addInterface(NetworkAddress *newAddress){
//  UINT32 ipv4addr = newAddress->IPv4GetAddress();
//  ipv4addr=htonl(ipv4addr);
//  size+=sizeof(newAddress->IPv4GetAddress());
//  interfaceCount++;
//  return interfaces.append((void*)&ipv4addr,sizeof(newAddress->IPv4GetAddress()));
//}
bool
HelloMessage::addLinkMessage(LinkMessage *newMessage){
  size+=newMessage->size;

  //void* rawMessage=malloc(newMessage->size);
  char* rawMessage = new char[newMessage->size];

  if(!rawMessage){
    fprintf(stderr,"malloc returned null pointer in HelloMessage::addLinkmessage\n");
    return 0;
  }
  //char rawMessage[1024];
  int sizeused = newMessage->pack((char*)rawMessage,newMessage->size);
  if(sizeused<0){
    fprintf(stderr,"HelloMessage::addLinkMessage error packing newmessage, %d is newMessage size\n",newMessage->size);
//    DMSG(8,"HelloMessage::addLinkMessage error packing newmessage, %d is newMessage size\n",newMessage->size);
    return false;
  }
  int returnvalue = messages.append((char*)rawMessage,newMessage->size);
 
  //free(rawMessage);
  delete[] rawMessage;

  if(returnvalue!=0)
	return true;
  return false;
}


int
HelloMessage::pack(char* buffer,int maxSize){
  int sizeused=4;
  ((UINT16*)buffer)[0]=reserved1;
  ((UINT8*)buffer)[2]=htime;
  ((UINT8*)buffer)[3]=willingness;
  //  sizeused+=interfaces.pack(&buffer[sizeused],maxSize-sizeused);
  //if(sizeused<4){
  //  fprintf(stderr,"HelloMessage::pack error packing interfaces, %d is my maxSize, %d is my willingness\n",maxSize,willingness);
  //  return -1;
  //}
  int messagepacksize=messages.pack(&buffer[sizeused],maxSize-sizeused);
  if(messagepacksize<0){
    fprintf(stderr,"HelloMessage::pack error packing link messages, %d is my maxSize, %d is my sizeused, %d is my willingness\n",maxSize,sizeused,willingness);
    return -1;
  }
  sizeused+=messagepacksize;
  return sizeused;
}
int
HelloMessage::unpack(char* buffer,int maxSize){
  //interfaces.destroy();
  //messages.destroy();
  reserved1=((UINT16*)buffer)[0];
  qDebug() << "Hello reserved1: " << reserved1 << '\n';
  htime=((UINT8*)buffer)[2];
  qDebug() << "Hello htime: " << htime << '\n';
  willingness=((UINT8*)buffer)[3];
  qDebug() << "Hello willingness: " << willingness << '\n';
  //  int loopsize = (int)interfaceCount;
  //fprintf(stdout,"HelloMessage::unpack %d reserved1, %d htime, %d willingness\n",reserved1,htime,willingness);
  int totalsizeused=4;//(1+loopsize)*4;
  //NetworkAddress newinterface;
  //for(int i=1;i<=loopsize;i++){
  //  newinterface.SetRawHostAddress(IPv4,buffer+i*4,4);
  //  addInterface(&newinterface);
  //}
  //interfaceCount=(UINT8)buffer[3]; //have to set this back cause adding interfaces incriments the count;
  int sizeused=0,maxloop=0;
  for(int i=4;i<maxSize;i+=sizeused){
    LinkMessage newmessage;
    maxloop++;
    sizeused = newmessage.unpack(&(buffer[i]),maxSize-i);
    //DMSG(8,"HelloMessage unpacked linkmessage of size %d \n",sizeused);
    //    sizeused = newmessage.unpack((char*)&(((UINT32*)buffer[i])),maxSize-i*4);
    totalsizeused+=sizeused;
    addLinkMessage(&newmessage);
    if(maxloop>500) {
      fprintf(stderr,"HelloMessage::unpack may have infinate loop, breaking\n");break;
    }
  }
  if(totalsizeused!=maxSize){
    fprintf(stderr,"HelloMessage::unpack:: maxSize %d should be set equal to what totalsizeuesed %d ends up being and it isn't!\n",maxSize,totalsizeused);
  }
  return totalsizeused;
}
//end HelloMessage class

//LinkMessage stuff
bool
LinkMessage::addNeighbor(UINT32 newAddress){
  
    UINT32 ipv4addr = newAddress;
    size+=sizeof(newAddress); // important to keep current size up to date;
    //fprintf(stderr,"%d is size of ipv4hostaddr which is what I am adding |",sizeof(newAddress->IPv4GetAddress()));
    return neighbors.append((char*)&ipv4addr,4);
}

bool
LinkMessage::addNeighborExtra(UINT32 newAddress,unsigned long degree){
  bool returnvalue = false;
  reserved = 1; //this link message contains extra information.

    UINT32 ipv4addr = newAddress;
    size+=sizeof(newAddress)+4; // important to keep current size up to date;
    //fprintf(stderr,"%d is size of ipv4hostaddr which is what I am adding |",sizeof(newAddress->IPv4GetAddress()));
    returnvalue = neighbors.append((char*)&ipv4addr,4);  
    returnvalue &= degrees.append((char*)&degree,4);

  return returnvalue;
}
int
LinkMessage::pack(char* buffer,int maxSize){
  int sizeused=4;
  memset(buffer,0,maxSize);
  ((UINT8*)buffer)[0]=linkCode;
  ((UINT8*)buffer)[1]=reserved;
  if(size>4){
    sizeused += neighbors.pack(&buffer[sizeused],maxSize-sizeused);
    if(reserved == 1){
      sizeused += degrees.pack(&buffer[sizeused],maxSize-sizeused);
    }
    if(sizeused<4){
      fprintf(stderr,"LinkMessage::pack error packing neighbors %d is my maxSize,%d was my size value\n",maxSize,size);
//      DMSG(8,"LinkMessage::pack error packing neighbors %d is my maxSize,%d was my size value\n",maxSize,size);
      return -1;
    }
  }
  ((UINT16*)buffer)[1]=(UINT16)sizeused;
  //(UINT16)buffer[2]=sizeused;
  return sizeused;
}
int 
LinkMessage::unpack(char* buffer,int maxSize){
  linkCode=(UINT8)buffer[0];
  reserved=(UINT8)buffer[1];
  size=((UINT16*)buffer)[1];
  //fprintf(stdout,"LinkMessage::unpack %d linkCode,%d reserved,%d size\n",linkCode,reserved,size);
  if(size>maxSize){
    fprintf(stderr,"Linkmessage::unpack:: insufficent room for unpacking! size=%d maxSize=%d\n",size,maxSize);
    return 0;
  }
  //  neighbors.destroy();
  UINT32 newaddress;
  if(reserved ==0){
    for(int i=1;i<(size/4);i++){ //loop for getting addresses
    memmove(&newaddress,buffer+i*4,4);
    addNeighbor(newaddress);
	size-=4;//addNeighbor changes the size this is to correct it
  }

  } else { //reserved ==1 link message contains extra information
    unsigned long degree;
    int numberofaddrs = 0; 
    numberofaddrs = (size/4-1)/2;
    for(int i=1;i<=numberofaddrs;i++){ //loop for getting addresses
        memmove((void*)newaddress,buffer+i*4,4);
        degree = *(unsigned long*)(buffer+(i+numberofaddrs)*4);
        addNeighborExtra(newaddress,degree);
        size-=8;//addNeighbor changes the size this is to correct it
    }

  }
  if(size!=((UINT16*)buffer)[1]) { //I don't see what I was trying to check here??? doesn't seem right at all!?
    fprintf(stderr,"LinkMessage::unpack size value somehow ended up different than size value in header!!!!!!!!!!\n");
  }
  //  size=((UINT16*)buffer)[1]; // have to reset the size cause adding addresses messed with the value
  return size;
}
//end LinkMessage class

//List class stuff
//List::List(List &listToCopy){
//  fprintf(stdout,"repeating here\n");
//  head=NULL;tail=NULL;
//  void* object=NULL;
//  int objectsize=0;
//  listToCopy.peekInit();
//  while((object = listToCopy.peekNext(&objectsize))){
//    append(object,objectsize);
//  }
//}
  
bool
List_::append(char* object, int size){
  //set up new list node 
  ListNode* newListNodePtr =new ListNode;
  //fprintf(stdout,"|books %d| ",++books);
  newListNodePtr->size=size;
  
  //newListNodePtr->object=malloc(size);
  newListNodePtr->object = (char*) new char[size];

  //  fprintf(stdout,"|malloced %d bytes books %d| ",size,++books);
  if(!newListNodePtr->object){
    fprintf(stderr,"malloc returned null pointer in list::append\n");
    return 0;
  }
  memmove(newListNodePtr->object,object,size);
  //add new object to list
  if((newListNodePtr->prev=tail))
    tail->next=newListNodePtr;
  else
    head=newListNodePtr;
  newListNodePtr->next=NULL;
  tail=newListNodePtr;
  return true;
}
bool
List_::destroy(){
  //  fprintf(stderr,"in list destroy\n");
  ListNode* listNodePtr=head;
  while((head=listNodePtr)){
    listNodePtr=head->next;
    
    //free(head->object);
    delete[] head->object;
    
    //fprintf(stdout,"books %d ",--books);
    
    //free(head);
    delete head;
    
    //fprintf(stdout,"books %d ",--books);
  }
  head=NULL;
  tail=NULL;
  peekptr=NULL;
  return true;
}
int
List_::pack(char* buffer,int maxSize){
  memset(buffer,0,maxSize);
  ListNode* currentPtr=head;
  int localSize=0;
  while(currentPtr!=NULL){
    localSize+=currentPtr->size;
    if(localSize<=maxSize){
      memmove((buffer+localSize-currentPtr->size),currentPtr->object,currentPtr->size);
    }   
    else{
//      DMSG(8,"List::pack:: buffer size insufficent for packing list maxsize=%d localsize=%d\n",maxSize,localSize);
      fprintf(stderr,"List::pack:: buffer size insufficent for packing list maxsize=%d localsize=%d\n",maxSize,localSize);
      return -1; 
    }
    currentPtr=currentPtr->next;
  }
  return localSize;
}
char*
List_::peekNext(int *sizeptr){
  if(peekptr)
    peekptr=peekptr->next;
  else 
    peekptr=head;
  if(peekptr){
    *sizeptr = peekptr->size;
    return peekptr->object;
  }else{
    return NULL;
    *sizeptr = 0;
  }
}
