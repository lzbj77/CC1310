#ifndef SERIALPORTHANDLER_H
#define SERIALPORTHANDLER_H

#include <QtSerialPort/QSerialPort>

#include <QTimer>
#include <QByteArray>
#include <QObject>


class SerialPortHandler : public QObject
{
    Q_OBJECT

public:
    explicit SerialPortHandler(QSerialPort *serialPort, QObject *parent = 0);
    ~SerialPortHandler();

    bool SendData(const QByteArray &writeData);

signals:

    RoutingPacketArrived(QByteArray &packet);


private slots:
    void handleBytesWritten(qint64 bytes);
    void handleReadyRead();
    void handleError(QSerialPort::SerialPortError error);
    void handleTimeout();

private:
    QSerialPort     *m_serialPort;
    QByteArray      m_writeData;
    qint64          m_bytesWritten;
};

#endif //SERIALPORTHANDLER_H
