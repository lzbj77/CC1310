#include "timermanager.h"

TimerManager::TimerManager(int hello_interval, int rand_value, QObject *parent)
    : QObject(parent)
    , hello_timer(this)
    , hello_jitter_timer(this)
{
    hello_timer.setSingleShot(false);
    hello_timer.setInterval(hello_interval);
    hello_timer.start();

    hello_jitter_timer.setSingleShot(true);
    hello_jitter_timer.setInterval(rand_value);
    hello_jitter_timer.start();
}

TimerManager::~TimerManager()
{
    if (hello_timer.isActive()) hello_timer.stop();
    if (hello_jitter_timer.isActive()) hello_jitter_timer.stop();
}

void TimerManager::Start(double rand_value)
{
    hello_jitter_timer.setInterval(rand_value);
    hello_jitter_timer.start();
}

void TimerManager::Stop()
{
    hello_jitter_timer.stop();
}
