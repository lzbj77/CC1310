// Для того, чтобы пакет воспринимался не как маршрутный, надо в строчке 95 поменять условие
#include "serialporthandler.h"
#include <qdebug.h>

#include <QCoreApplication>

SerialPortHandler::SerialPortHandler(QSerialPort *serialPort, QObject *parent)
    : QObject(parent)
    , m_serialPort(serialPort)
    , m_bytesWritten(0)
{
    if (m_serialPort->open(QIODevice::ReadWrite)) {
        if (m_serialPort->setBaudRate(9600)
                && m_serialPort->setDataBits(QSerialPort::Data8)//DataBits
                && m_serialPort->setParity(QSerialPort::NoParity)
                && m_serialPort->setStopBits(QSerialPort::OneStop)
                && m_serialPort->setFlowControl(QSerialPort::NoFlowControl))
        {
            if (m_serialPort->isOpen()){
                qDebug() << m_serialPort->portName() << " >> is open!\r\n";
            }
        } else {
            m_serialPort->close();
            qDebug() << m_serialPort->errorString();
          }
    } else {

        m_serialPort->close();
        qDebug() << m_serialPort->errorString();
    }

    connect(m_serialPort, SIGNAL(bytesWritten(qint64)), SLOT(handleBytesWritten(qint64)));
    connect(m_serialPort, SIGNAL(readyRead()), this, SLOT(handleReadyRead()));
    connect(m_serialPort, SIGNAL(error(QSerialPort::SerialPortError)), SLOT(handleError(QSerialPort::SerialPortError)));
}

SerialPortHandler::~SerialPortHandler()
{
    m_serialPort->close();
    delete m_serialPort;
}

void SerialPortHandler::handleBytesWritten(qint64 bytes)
{
    m_bytesWritten += bytes;
    if (m_bytesWritten == m_writeData.size()) {
        m_bytesWritten = 0;
        qDebug() << QObject::tr("Data successfully sent to port %1:").arg(m_serialPort->portName()) << endl;
        qDebug() << m_writeData.toHex() << endl;
//        QCoreApplication::quit();
        m_serialPort->clear(QSerialPort::Output);
    }
}

void SerialPortHandler::handleTimeout()
{
    qDebug() << QObject::tr("Operation timed out for port %1, error: %2").arg(m_serialPort->portName()).arg(m_serialPort->errorString()) << endl;
    QCoreApplication::exit(1);
}

void SerialPortHandler::handleError(QSerialPort::SerialPortError serialPortError)
{
    if (serialPortError == QSerialPort::WriteError) {
        qDebug() << QObject::tr("An I/O error occurred while writing the data to port %1, error: %2").arg(m_serialPort->portName()).arg(m_serialPort->errorString()) << endl;
        QCoreApplication::exit(1);
    }
}

bool SerialPortHandler::SendData(const QByteArray &writeData)
{
    // Sync
    QByteArray sync(4, char(0x0101));
    m_writeData = writeData;
    m_writeData.prepend(sync);
// можно добавить CRC

    qint64 bytesWritten = m_serialPort->write(m_writeData);

    if (bytesWritten == -1) {
        qDebug() << QObject::tr("Failed to write the data to port %1, error: %2").arg(m_serialPort->portName()).arg(m_serialPort->errorString()) << endl;
        return false;
//        QCoreApplication::exit(1);
    } else if (bytesWritten != m_writeData.size()) {
        qDebug() << QObject::tr("Failed to write all the data to port %1, error: %2").arg(m_serialPort->portName()).arg(m_serialPort->errorString()) << endl;
        return false;
//        QCoreApplication::exit(1);
    }

    return true;
//    m_timer.start(5000);
}

void SerialPortHandler::handleReadyRead()
{

    QByteArray sync(4, char(0x0101));
    QByteArray data = m_serialPort->readAll();
    qDebug() << "--------\r\nBytes read:\r\n" << data.toHex() << "\r\n----------\r\n";
    m_serialPort->clear(QSerialPort::Input);

    if (data.startsWith(sync))
    {
        //Открепили синхропосылку
        int len = data.length() - sync.length();
        data = data.right(len);

        //Можно открепить CRC




        qDebug() << "Routing data: " << data;
        emit(RoutingPacketArrived(data));
    }
}
