#include "nrlolsr.h"
#include "QDebug"
#include "time.h"
#include "QThread"

Nrlolsr::Nrlolsr(unsigned int myAddr, QSerialPort *serialPort, QObject *parent)
    : QObject(parent)
    , serialPortHandler(serialPort)
//    , hello_timer(0)
//    , hello_jitter_timer(0)
//    , watchdog_timer(0)
{

    srand((unsigned)time(0));
    //    serialPortHandler(*serialPort);
    connect(&serialPortHandler, SIGNAL(RoutingPacketArrived(QByteArray&)), this, SLOT(GetRoutingPacket(QByteArray&)));
    connect(&udpSocketHandler, SIGNAL(RoutingPacketArrived(QByteArray&)), this, SLOT(GetRoutingPacket(QByteArray&)));

    invalidAddress = INVALID_ADDRESS;

    myaddress = myAddr;



    updateSmfForwardingInfo = false; //set to true when mpr selector list changes and send at end of parcing hello message which changed mpr selector list
    floodingType = SMPR;  //default forwarding engine is set to source based mpr flooding.

    Neighb_Hold_Time = 46.0; //is default value changed on Start();

    // hello timer stuff
    Hello_Interval = 10.5 ; //in seconds
    Hello_Timeout_Factor = 6.0;
    Hello_Jitter =.5; //% of Hello_Interval

    //set class variables
    D_Hold_Time=15.0; //in seconds

    // init hysteris values
    T_up = .4;
    T_down = .15;
    alpha = .7; //weight given to past

    localWillingness = WILL_DEFAULT;

    pseqno = 0;
    seqno = 0;
    mssn = 0;

    newThread = new QThread(this);


//    connect(&watchdog_timer, SIGNAL(timeout()), this, SLOT(OnWatchdogTimeout()));


//    connect(&delayed_forward_timer, SIGNAL(timeout()), this, SLOT(OnDelayedForwardTimeout()));
//    connect(newThread, SIGNAL(started()), &watchdog_timer, SLOT(start()));

//    connect(newThread, SIGNAL(started()), &hello_timer, SLOT(start()));
//    connect(newThread, SIGNAL(started()), &hello_jitter_timer, SLOT(start()));

//    connect(newThread, SIGNAL(finished()), &watchdog_timer, SLOT(stop()));

//    connect(newThread, SIGNAL(finished()), &hello_timer, SLOT(stop()));
//    connect(newThread, SIGNAL(finished()), &hello_jitter_timer, SLOT(stop()));



//    connect(this, SIGNAL(PrintTimers()), this, SLOT(OnWatchdogTimeout()));
}

Nrlolsr::~Nrlolsr()
{
}

bool Nrlolsr::Start(int ifIndex)
{
    //    Test();

    //    getchar();
    interfaceIndex = ifIndex;

    Hello_Interval *= 1000;

    Neighb_Hold_Time = Hello_Timeout_Factor*Hello_Interval;
    //    Mantissa_Hello_Hold_Interval = doubletomantissa(Neighb_Hold_Time);
    Mantissa_Hello_Interval = doubletomantissa(Hello_Interval);


    nbr_list.SetHoldTime(Neighb_Hold_Time);         //list of neighbors
    nbr_list_old_for_hello.SetHoldTime(Neighb_Hold_Time);  //copy of list of neighbors only used when tcSlowDown is turned on used between recieved hello messages

    nbr_2hop_list.SetHoldTime(Neighb_Hold_Time);    //list of 2 hop neighbors
    duplicateTable.SetHoldTime(D_Hold_Time);        //list of duplicates default 15 sec

    realRouteTable.Init();

//    watchdog_timer.setInterval(5000);
//    watchdog_timer.setSingleShot(false);
//    watchdog_timer.moveToThread(newThread);

//    watchdog_timer.start();

//    hello_timer.setInterval(Hello_Interval);
//    hello_timer.setSingleShot(false);
//    hello_timer.moveToThread(newThread);

//    hello_timer.start();

    double randValue = UniformRand(Hello_Interval)*Hello_Jitter;
//    hello_jitter_timer.setInterval(randValue);
//    hello_jitter_timer.setSingleShot(true);
//    hello_jitter_timer.moveToThread(newThread);

    myTimerMgr = new TimerManager(Hello_Interval, randValue, 0);

    connect(&(myTimerMgr->hello_timer), SIGNAL(timeout()), this, SLOT(OnHelloTimeout()));
    connect(&(myTimerMgr->hello_jitter_timer), SIGNAL(timeout()), this, SLOT(OnHelloTimeout()));

    connect(this, SIGNAL(StartTimer(double)), myTimerMgr, SLOT(Start(double)));
    connect(this, SIGNAL(StopTimer()), myTimerMgr, SLOT(Stop()));

//    hello_jitter_timer.start();
    myTimerMgr->moveToThread(newThread);

    newThread->start();
    return true;
}

void Nrlolsr::Test()
{
    HelloMessage hellomessage;
    hellomessage.htime = 1/*Mantissa_Hello_Interval*/; //this value is not currently processed upon being recieved.
    hellomessage.willingness = 2/*localWillingness*/;
    //    hellomessage.addLinkMessage(&symlinks);
    //    hellomessage.addLinkMessage(&mprlinks);
    //    hellomessage.addLinkMessage(&lostlinks);
    //    hellomessage.addLinkMessage(&asymlinks);

    // build up Olsr message
    OlsrMessage olsrmessage;
    olsrmessage.type=NRLOLSR_HELLO;
    olsrmessage.Vtime = doubletomantissa(6.0/*Neighb_Hold_Time*/);
    olsrmessage.SetO_addr(0x00114433/*myaddress*/);
    olsrmessage.ttl=1;
    olsrmessage.D_seq_num=25/*seqno*/;
    olsrmessage.setHelloMessage(&hellomessage);

    HelloMessage hellomessage2;
    hellomessage2.htime = 0/*Mantissa_Hello_Interval*/; //this value is not currently processed upon being recieved.
    hellomessage2.willingness = 4/*localWillingness*/;
    //    hellomessage.addLinkMessage(&symlinks);
    //    hellomessage.addLinkMessage(&mprlinks);
    //    hellomessage.addLinkMessage(&lostlinks);
    //    hellomessage.addLinkMessage(&asymlinks);

    // build up Olsr message
    OlsrMessage olsrmessage2;
    olsrmessage2.type=NRLOLSR_HELLO;
    olsrmessage2.Vtime = doubletomantissa(6.0/*Neighb_Hold_Time*/);
    olsrmessage2.SetO_addr(0x00121233/*myaddress*/);
    olsrmessage2.ttl=1;
    olsrmessage2.D_seq_num=45/*seqno*/;
    olsrmessage2.setHelloMessage(&hellomessage2);

    //    sending hello out
    olsrpacket2forward.addOlsrMessage(&olsrmessage);
    olsrpacket2forward.addOlsrMessage(&olsrmessage2);
    char buffer[1500];
    int buffersize=olsrpacket2forward.pack(buffer,1500);
    unsigned int len = buffersize;

    QByteArray data(buffer, len);


    serialPortHandler.SendData(data);

    olsrpacket2forward.clear();

    //    GetRoutingPacket(data);
}

UINT8 Nrlolsr::doubletomantissa(double timeinseconds){

    int a, b;
    UINT8 mantissatime=0;
    for(b = 0;(double)timeinseconds/TIME_CONSTANT >= (double)pow(2,b);b++);//  fprintf(stdout,"%f first %f second\n",(double)timeinseconds/TIME_CONSTANT,(double)pow(2,b));
    b--;
    if(b<0){ //number was too small make smallest number possible
        a = 1;
        b = 0;
    } else if (b>15){ //number was too large make largest number possible
        a = 15;
        b = 15;
    } else { //everything is fine
        a = (int)(16*((double)timeinseconds/(TIME_CONSTANT*(double)pow(2,b))-1));
        while(a>=16){
            a-=16;
            b++;
        }
    }
    mantissatime = a*16+b;
    //DMSG(6,"Exit: Nrlolsr::doubletomantissa(timeinseconds %d)\n",tieminseconds);
    return mantissatime;
}

double Nrlolsr::mantissatodouble(UINT8 mantissatime){
    //DMSG(6,"Enter: Nrlolsr::mantissatodouble(mantissatime %d)\n",mantissatime);
    int a = mantissatime>>4;
    int b = mantissatime - a*16;
    double returntime = (double)(TIME_CONSTANT*(1+(double)a/16)*(double)pow(2,b));
    //DMSG(6,"Exit: Nrlolsr::mantissatodouble(mantissatime %d)\n",mantissatime);
    return returntime;
}


//TBIs here
void Nrlolsr::GetRoutingPacket(QByteArray &packet)
{
//    qDebug() << "Enter: GetRoutingPacket()\r\n";
    bool redoroutingtable = false;
    char buffer[1500];
    unsigned int len = packet.length(), TEMPORARY_LENGTH = (UINT16)packet[0];
    if (len != TEMPORARY_LENGTH)
        len = TEMPORARY_LENGTH;

    memmove(buffer, packet.data(), len);

    UINT32 addr;
    // New logic here, need to get message (buffer), message length (len) and source address (addr)

    if((len % 4) != 0){
        qDebug() << QString("Invalid routing packet size %1 value \n").arg(len);
        return;
    }

    OlsrPacket olsrpacket;
    olsrpacket.unpack(buffer,len/*,ipvMode*/);
    //cleaning up tables and preparing to parse messages
    nb_purge();
    dup_purge();
    // go though the messages
    char* littlebuffer;
    int olsrmessagesize = 0;
    int messagenumberindex=0;
    while((littlebuffer = (char*)olsrpacket.messages.peekNext(&olsrmessagesize))){
        messagenumberindex++;
        OlsrMessage olsrmessage;
        olsrmessage.unpack(littlebuffer,olsrmessagesize/*,ipvMode*/);

        if(IsDuplicate(olsrmessage.O_addr,olsrmessage.D_seq_num)){ // checking to see if message has already been processed.
            qDebug() << "recieved duplicate, dropping \n";
        } else { //first time recieving message process it

            addr = olsrmessage.O_addr;
            addDuplicate(olsrmessage.O_addr,olsrmessage.D_seq_num);
            int olsrmessageheadersize = 8;

            olsrmessageheadersize +=4;

            if(olsrmessage.type==NRLOLSR_HELLO){
                redoroutingtable = true;

                //its a hello message parse the interface messages lists
                //process the originator address
                HelloMessage hellomessage;
                hellomessage.unpack(olsrmessage.message,olsrmessage.size-olsrmessageheadersize/*,ipvMode*/);
//                UINT8 spfValue=0;
//                UINT8 minmaxValue=0;
                update_nbr(olsrmessage.O_addr,ASYM_LINKv4/*,spfValue,minmaxValue*/,olsrmessage.Vtime,hellomessage.willingness);

                //go though neighbor different link types
                hellomessage.messages.peekInit();
                int linkmessagesize=0;
                unsigned long onehopnodedegree=0;
                while((littlebuffer = (char*)hellomessage.messages.peekNext(&linkmessagesize))){ //loop to process link messages
                    LinkMessage linkmessage;
                    //the next 2 variable are only used for manet ospf extensions used in conjunction with smf code.
                    unsigned long twohopnodedegree = 0; //this is only used for manet ospf extensions
                    int degreesize=0; //this isn't really needed because degree size is always 4
                    //end ospf variables;

                    linkmessage.unpack(littlebuffer,linkmessagesize/*,ipvMode*/);
                    linkmessage.neighbors.peekInit();
                    int neighboraddresssize=0;
                    switch(linkmessage.linkCode) {

                    case ASYM_LINKv4:
                        while((littlebuffer = (char*)linkmessage.neighbors.peekNext(&neighboraddresssize))){ //sets littlebuffer to next object size in addresssize
                            UINT32 nbr_addr;
                            memmove(&nbr_addr, &littlebuffer[0],neighboraddresssize);

                            if(nbr_addr == myaddress){
                                UINT8 spfValue=0;
                                UINT8 minmaxValue=0;
                                update_nbr(olsrmessage.O_addr,SYM_LINKv4,spfValue,minmaxValue);
                            }
                        }
                        break;

                    case SYM_LINKv4:
                    case MPR_LINKv4:
                        if(linkmessage.reserved==1) { //message has degree information
                            linkmessage.degrees.peekInit();
                        }
                        while((littlebuffer = (char*)linkmessage.neighbors.peekNext(&neighboraddresssize))){
                            onehopnodedegree++;
                            if(linkmessage.reserved==1){
                                twohopnodedegree = *(unsigned long*)linkmessage.degrees.peekNext(&degreesize);
                            }
                            //	      UINT32 neighboraddress = ntohl(((UINT32*)littlebuffer)[0]);
                            UINT32 nbr_addr;
                            memmove(&nbr_addr, &littlebuffer[0],neighboraddresssize);

                            if(nbr_addr == myaddress){	      //if(neighboraddress==myaddress.IPv4HostAddr()){
                                update_mprselector(olsrmessage.O_addr,linkmessage.linkCode); //add/remove from mpr selector set depending on type
                                UINT8 spfValue=0;
                                UINT8 minmaxValue=0;
                                update_nbr(olsrmessage.O_addr,SYM_LINKv4,spfValue,minmaxValue); // will update the time this doesn't mean its not an mpr
                            } else {
                                //DMSG(9,"updating 2 hop neighbor table\n");
                                if(linkmessage.reserved == 0){
                                    update_2hop_nbr(olsrmessage.O_addr,nbr_addr);
                                } else {
                                    update_2hop_nbrExtra(olsrmessage.O_addr,nbr_addr,twohopnodedegree);
                                }
                            }
                        }
                        //DMSG(8,"returned from update in sym/mpr \n");
                        break;

                    case LOST_LINKv4:
                        //DMSG(8,"in the lostlink area \n");
                        while((littlebuffer = (char*)linkmessage.neighbors.peekNext(&neighboraddresssize))){
                            //UINT32 neighboraddress = ntohl(((UINT32*)littlebuffer)[0]);
                            UINT32 nbr_addr;
                            memmove(&nbr_addr, &littlebuffer[0],neighboraddresssize);
                            if(nbr_addr == myaddress){  // if(neighboraddress==myaddress.IPv4HostAddr()){
                                //make asym link and lose all of its 2 hop neighbors
                                UINT8 spfValue=0;
                                UINT8 minmaxValue=0;
                                update_nbr(olsrmessage.O_addr,LOST_LINKv4,spfValue,minmaxValue);
                            } else {
                                remove_2hop_link(olsrmessage.O_addr,nbr_addr);
                            }
                        }
                        //DMSG(8,"returned from updating in lost area \n");
                        break;
                    }
                }

                if(NeighborsStableForHello()){
                    redoroutingtable=false;
                }
                //	DMSG(8,"finished parsing hello message\n");
                //printCurrentTable(3);


                //???TBI???                if(updateSmfForwardingInfo){
                //                    SendForwardingInfo();
                //                }
            }



            //finished processing message check for forwarding and duplicate entry
            //we need to check for symetry before continuing to forwarding section
            NbrTuple* sym_check_ptr;

            sym_check_ptr = nbr_list.FindObject(addr);
            if(sym_check_ptr){
                if((sym_check_ptr->N_status == SYM_LINKv4) || (sym_check_ptr->N_status == MPR_LINKv4)){ //neighbor is symetric and packet can be added to dup table.
                    //            //check to see if neighbor is semetric
                    addDuplicate(olsrmessage.O_addr,olsrmessage.D_seq_num);
                }
            }
        }
    }
    redoroutingtable = true; // theres a problem currently with timed out neighbors not setting flag. but this was using too much cpu time so redoing routes on hellos
    if(redoroutingtable) {
        makeNewRoutingTable();
    }
    //DMSG(6,"Exit: Nrlolsr::OnSocketEvent(thesocket,theEvent)\n");
    return;

}

//TBIs here
int Nrlolsr::IsDuplicate(UINT32 addr, UINT16 dseqno){
    NbrTuple *tuple = duplicateTable.FindObject(addr);
    //TBI  printDuplicateTable(8);
    if(addr == myaddress){
        return 1;
    }
    while(tuple){
        if(tuple->seq_num==dseqno){
            qDebug() << addr << " with seq num " << dseqno << " is DUP!\n";
            return 1;
        }
        tuple = duplicateTable.FindNextObject(addr);
    }
    return 0;
}

void Nrlolsr::addDuplicate(UINT32 dupaddr, UINT16 dseqno){
    NbrTuple *tuple = duplicateTable.FindObject(dupaddr);
    while(tuple){
        if(tuple->seq_num==dseqno){
            tuple->N_time = InlineGetCurrentTime()+D_Hold_Time;
            return;
        }
        tuple = duplicateTable.FindNextObject(dupaddr);
    }
    tuple = new NbrTuple;
    tuple->seq_num = dseqno;
    tuple->N_addr = dupaddr;
    tuple->N_time = InlineGetCurrentTime()+D_Hold_Time;
    duplicateTable.QueueObject(tuple);
    //  printDuplicateTable(4);
}

int Nrlolsr::update_nbr(UINT32 id, int status/*, UINT8 spfValue, UINT8 minmaxValue*/) {
    NbrTuple *tuple_pt, *children, *parents;
//    int updateMprs=0;
    tuple_pt = nbr_list.FindObject(id);
    switch(status) {
    case ASYM_LINKv4:
        qDebug() << "error in Nrlolsr::update_nbr(short call function) in ASYM_LINKv4 area should never happen\n";
        break;
    case SYM_LINKv4:  // can be mpr link as well
        if(tuple_pt) { //should always pass if done correctly
            // update link time
            if(tuple_pt->N_status==ASYM_LINKv4){ //link was asym before now its a symetric link
                tuple_pt->hop=1;
                tuple_pt->N_status=SYM_LINKv4;
                //link up known children
                for(children=(tuple_pt->children).PeekInit();children!=NULL;children=(tuple_pt->children).PeekNext()){
                    if(children!=NULL){
                        if((children->stepparents).FindObject(tuple_pt->N_addr)){ //remove stepparent status
                            (children->stepparents).RemoveCurrent();
                        } else {
                            //          DMSG(0,"didn't find stepparents in SYM_LINKv4 area!!!  updated node %s with child ",tuple_pt->N_addr.GetHostString());
                            //          DMSG(0,"%s who doesn't know about ",children->N_addr.GetHostString());
                            //          DMSG(0,"%s\n",tuple_pt->N_addr.GetHostString());
                        }
                        (children->parents).QueueObject(tuple_pt); // link the child to parent node
                        if(nbr_2hop_list.FindObject(children->N_addr)){//need to take out if its there already to update time
                            nbr_2hop_list.RemoveCurrent();
                        } else {
                            // is okay cause could have been only a 1 hop neighbor
                        }
                        nbr_2hop_list.QueueObject(children); // add to two hop list
                    }
                }
//                updateMprs=1;
            }
            //DMSG(7,"Moving %s to the sym neighbor table \n",id.GetHostString());
            nbr_list.RemoveCurrent();
            tuple_pt->N_time=InlineGetCurrentTime() + Neighb_Hold_Time;
            //tuple_pt->N_spf=spfValue;
            //tuple_pt->N_minmax=minmaxValue;
            nbr_list.QueueObjectAddressSort(tuple_pt); //sorts neighbors by address to avoid route flapping
            //checkCurrentTable(2);
        } else {
            qDebug() << "Error1\n";//  DMSG(0,"Error: didn't pass for some reason Nrlolsr::nbr_update,sym_link");
        }
        break;
    case LOST_LINKv4:  //recieved a lost link from a neighbor you can still hear
        if(tuple_pt) { //should always pass
            //DMSG(7,"changing nb %s to asym list at time %f \n",tuple_pt->N_addr.GetHostString(),InlineGetCurrentTime());
            // check and remove nodes children
            nbr_list.RemoveCurrent();
            for(children=(tuple_pt->children).PeekInit();children!=NULL;children=(tuple_pt->children).PeekNext()){
                if(children!=NULL){
                    //abandon children
                    if((children->parents).FindObject(tuple_pt->N_addr))
                        (children->parents).RemoveCurrent();
                    else if((children->stepparents).FindObject(tuple_pt->N_addr))
                        (children->stepparents).RemoveCurrent();
                    if((children->parents).IsEmpty()){
                        //child lost last parent, child runs free
                        //DMSG(7,"removing 2 hop %s ",children->N_addr.GetHostString());
                        //DMSG(7,"cause %s deleated (lost link)\n",tuple_pt->N_addr.GetHostString());
                        fflush(stdout);
                        nbr_2hop_list.FindObject(children->N_addr);
                        nbr_2hop_list.RemoveCurrent();
                        if(!nbr_list.FindObject(children->N_addr)){ //check to see if it was exclusivly a 2 hop neighbor
                            //get rid of step children
                            for(parents=(children->children).PeekInit();parents!=NULL;parents=(children->children).PeekNext()){
                                if(parents!=NULL){
                                    if((parents->stepparents).FindObject(children->N_addr)){
                                        (parents->stepparents).RemoveCurrent();
                                    } else {
                                        //error statements shouldn't enter here
                                        if((parents->parents).FindObject(children->N_addr)){qDebug() << "Error2\n";
                                            //                                          DMSG(0,"missing stepparents link for node %s to stepparent ",parents->N_addr.GetHostString());
                                            //                                          DMSG(0,"%s in LOST_LINKv4 area:\n",children->N_addr.GetHostString());
                                            //                                          DMSG(0,"did find parent link! wasn't moved to stepparent correctly someplace in past!\n");
                                        } else { qDebug() << "Error3\n";
                                            //                                          DMSG(0,"missing stepparents link for node %s to stepparents ",parents->N_addr.GetHostString());
                                            //                                          DMSG(0,"%s in LOST_LINKv4 area: no parent link found\n",children->N_addr.GetHostString());
                                        }
                                        //end error stantments
                                    }
                                }
                            }
                            (children->children).Clear();
                            //get rid of step parents
                            for(parents=(children->stepparents).PeekInit();parents!=NULL;parents=(children->stepparents).PeekNext()){
                                if(parents!=NULL){
                                    //if(parents->N_addr.IPv4HostAddr()!=tuple_pt->N_addr.IPv4HostAddr()){
                                    if(parents->N_addr != tuple_pt->N_addr){
                                        if((parents->children).FindObject(children->N_addr)){
                                            (parents->children).RemoveCurrent();
                                        } else { qDebug() << "Error4\n";
                                            //              DMSG(0,"missing childlink for node %s to child ",parents->N_addr.GetHostString());
                                            //              DMSG(0,"%s in LOST_LINKv4 area: ",children->N_addr.GetHostString());
                                            //              DMSG(0,"%s stepparents was ",children->N_addr.GetHostString());
                                            //              DMSG(0,"%s\n",parents->N_addr.GetHostString());
                                        }
                                    }
                                }
                            }
                            (children->stepparents).Clear();

                            //	    if(children->hop==2){
                            //DMSG(10,"freeing it \n");
                            delete children;
                            //free(children);
                        }
                    }
                }
            }
            (tuple_pt->children).Clear();
            NbrTuple *mprtuple;
            if((mprtuple = mprSelectorList.FindObject(tuple_pt->N_addr))){
                mprSelectorList.RemoveCurrent();
                delete mprtuple;

                updateSmfForwardingInfo = true;  //send updated mpr selector list to send pipe if open

                //free(mprtuple);

            }
            //update current node
            if((tuple_pt->parents).IsEmpty()){ // has no parents can remain a 1 hop
                tuple_pt->hop=1;
            }
            else
                tuple_pt->hop=2;             // is now a 2 hop neighbor
            tuple_pt->N_time=InlineGetCurrentTime() + Neighb_Hold_Time;
            tuple_pt->N_status=ASYM_LINKv4;
            //tuple_pt->N_spf=spfValue;
            //tuple_pt->N_minmax=minmaxValue;
            nbr_list.QueueObjectAddressSort(tuple_pt);
            //nbr_list.QueueObject(tuple_pt);
        }
    }
    return 1;
}

int Nrlolsr::update_nbr(UINT32 id, int status/*, UINT8 spfValue, UINT8 minmaxValue*/, UINT8 Vtime, UINT8 willingness) {
    //DMSG(6,"Enter: Nrlolsr::update_nbr(id %s,status %d,spfValue %d,minmaxvalue %d)\n",id.GetHostString(),status,spfValue,minmaxValue);
    NbrTuple *tuple_pt, *children, *parents;
//    int updateMprs=0;
    tuple_pt = nbr_list.FindObject(id);
    if(tuple_pt==NULL){qDebug() << id << ": new neighbor!\n";
        //DMSG(8," neighbor %s not found in list\n",id.GetHostString());
    }
    switch(status) {
    case ASYM_LINKv4:
        //if(id.IPv4HostAddr()!=myaddress.IPv4HostAddr()) { // shouldn't ever happen
        if(id != myaddress){ // shouldn't ever happen
            if(tuple_pt) {
                qDebug() << "For neighbor " << id << " konectivity " << tuple_pt->konectivity << " is improving\n";
                tuple_pt->konectivity=alpha*tuple_pt->konectivity+(1-alpha);
                if(tuple_pt->N_status!=SYM_LINKv4 && tuple_pt->N_status!=MPR_LINKv4){
                    //if link is asym then update the object and move it to the back keeping asym status
                    //DMSG(8,"in asylink areas \n");
                    nbr_list.RemoveCurrent();
                    //printCurrentTable(3);
                    if(tuple_pt->konectivity>T_up && tuple_pt->N_status==PENDING_LINK){
                        tuple_pt->N_status=ASYM_LINKv4;
                    }
                    tuple_pt->N_time=InlineGetCurrentTime() + mantissatodouble(Vtime);
                    tuple_pt->N_willingness = willingness;
                    //tuple_pt->N_spf=spfValue;
                    //tuple_pt->N_minmax=minmaxValue;
                    nbr_list.QueueObjectAddressSort(tuple_pt);
                    //nbr_list.QueueObject(tuple_pt);
                    //DMSG(7,"refreshed one hop neighbor with timeout time %f\n",tuple_pt->N_time);
                }
            } else {
                // check to see if its a two hop neighbor
                tuple_pt = nbr_2hop_list.FindObject(id);
                if(tuple_pt) {
                    //set queue up for being one hop neighbor (handling timeouts of children)
                    tuple_pt->SetHoldTime(mantissatodouble(Vtime));
                    //add to 1 hop list but don't erase 2 hop list entry
                    tuple_pt->N_time=InlineGetCurrentTime() + mantissatodouble(Vtime);
                    //tuple_pt->konectivity=(1-alpha); //set initial konectivity value  //I think the below initial value works better
                    tuple_pt->konectivity=(T_up+T_down)/2;

                    //                    DMSG(8,"hello message reieved from known 2 hop neighbor setting konectivity to %f\n",tuple_pt->konectivity);
                    if(tuple_pt->konectivity>T_up){
                        tuple_pt->N_status=ASYM_LINKv4;
                        //tuple_pt->hop=1; //don't make it a one hop neighbor till its sym
                    } else {
                        //DMSG(7,"Adding %s nbr to pending \n",tuple_pt->N_addr.GetHostString());
                        tuple_pt->N_status=PENDING_LINK;
                    }
                    //tuple_pt->N_spf=spfValue;
                    //tuple_pt->N_minmax=minmaxValue;
                    tuple_pt->N_willingness = willingness;
                    nbr_list.QueueObjectAddressSort(tuple_pt);
                    //nbr_list.QueueObject(tuple_pt);
                } else {
                    //DMSG(2,"Adding %s asym neighbor table \n",id.GetHostString());
                    //not in current table add new tuple
                    tuple_pt = new NbrTuple;
                    tuple_pt->SetHoldTime(mantissatodouble(Vtime)); //set the queue up for the Vtime value
                    tuple_pt->N_addr=id;
                    //tuple_pt->konectivity=(1-alpha); //set initial konectivity value  //I think the below initial value works better
                    tuple_pt->konectivity=(T_up+T_down)/2;

                    //                    DMSG(8,"hello message reieved from new neighbor setting konectivity to %f\n",tuple_pt->konectivity);
                    if(tuple_pt->konectivity>T_up){
                        tuple_pt->N_status=ASYM_LINKv4;
                        tuple_pt->hop=1; //ok to do this here cause its a new neighbor
                    } else {
                        tuple_pt->N_status=PENDING_LINK;
                        tuple_pt->hop=1;  //ok to do this here cause its a new neighbor
                    }
                    tuple_pt->N_time=InlineGetCurrentTime() + Neighb_Hold_Time;
                    //tuple_pt->N_spf=spfValue;
                    //tuple_pt->N_minmax=minmaxValue;
                    tuple_pt->N_willingness = willingness;
                    nbr_list.QueueObjectAddressSort(tuple_pt);
                    //nbr_list.QueueObject(tuple_pt);
                }
            }
        }
        tuple_pt->recievedHello=1; //used for historisis
        //    qDebug() << id << ": I'm you new neiba, beiba!";
        if(tuple_pt->N_status==PENDING_LINK){
            //DMSG(6,"Exit: Nrlolsr::update_nbr(id %s,status %d,spfValue %d,minmaxValue)\n",id.GetHostString(),status,spfValue,minmaxValue);
            return 0;
        } else {
            //DMSG(6,"Exit: Nrlolsr::update_nbr(id %s,status %d,spfValue %d,minmaxValue)\n",id.GetHostString(),status,spfValue,minmaxValue);
            return 1;
        }
        break;
    case SYM_LINKv4:  // can be mpr link as well
        if(tuple_pt) { //should always pass if done correctly
            // update link time
            if(tuple_pt->N_status==ASYM_LINKv4){
                tuple_pt->hop=1;
                tuple_pt->N_status=SYM_LINKv4;
                //link up known children
                for(children=(tuple_pt->children).PeekInit();children!=NULL;children=(tuple_pt->children).PeekNext()){
                    if(children!=NULL){
                        if((children->stepparents).FindObject(tuple_pt->N_addr)){ //remove stepparent status
                            (children->stepparents).RemoveCurrent();
                        } else { qDebug() << "Error6\n";
                            //                            DMSG(0,"didn't find stepparents in SYM_LINKv4 area!!!  updated node %s with child ",tuple_pt->N_addr.GetHostString());
                            //                            DMSG(0,"%s who doesn't know about ",children->N_addr.GetHostString());
                            //                            DMSG(0,"%s\n",tuple_pt->N_addr.GetHostString());
                        }
                        (children->parents).QueueObject(tuple_pt); // link the child to parent node
                        if(nbr_2hop_list.FindObject(children->N_addr)){//need to take out if its there already to update time
                            nbr_2hop_list.RemoveCurrent();
                        } else {
                            // is okay cause could have been only a 1 hop neighbor
                        }
                        nbr_2hop_list.QueueObject(children); // add to two hop list
                    }
                }
//                updateMprs=1;
            }
            //DMSG(7,"Moving %s to the sym neighbor table \n",id.GetHostString());
            nbr_list.RemoveCurrent();
            tuple_pt->N_time=InlineGetCurrentTime() + Neighb_Hold_Time;
            //tuple_pt->N_spf=spfValue;
            //tuple_pt->N_minmax=minmaxValue;
            tuple_pt->N_willingness = willingness;
            nbr_list.QueueObjectAddressSort(tuple_pt);
            //nbr_list.QueueObject(tuple_pt);
            //checkCurrentTable(2);

            //this call is made only in send hello
            //if(updateMprs)
            //	selectmpr();
        }
        else { qDebug() << "Error7\n";
            //      DMSG(0,"didn't pass for some reason nrouter/nbr_update,sym_link");
        }
        break;
    case LOST_LINKv4:  //recieved a lost link from a neighbor you can still hear
        if(tuple_pt) { //should always pass
            //DMSG(7,"changing nb %s to asym list at time %f \n",tuple_pt->N_addr.GetHostString(),InlineGetCurrentTime());
            // check and remove nodes children
            nbr_list.RemoveCurrent();
            for(children=(tuple_pt->children).PeekInit();children!=NULL;children=(tuple_pt->children).PeekNext()){
                if(children!=NULL){
                    //abandon children
                    if((children->parents).FindObject(tuple_pt->N_addr))
                        (children->parents).RemoveCurrent();
                    else if((children->stepparents).FindObject(tuple_pt->N_addr))
                        (children->stepparents).RemoveCurrent();
                    if((children->parents).IsEmpty()){
                        //child lost last parent, child runs free
                        //DMSG(7,"removing 2 hop %s ",children->N_addr.GetHostString());
                        //DMSG(7,"cause %s deleated (lost link)\n",tuple_pt->N_addr.GetHostString());
                        fflush(stdout);
                        nbr_2hop_list.FindObject(children->N_addr);
                        nbr_2hop_list.RemoveCurrent();
                        if(!nbr_list.FindObject(children->N_addr)){ //check to see if it was exclusivly a 2 hop neighbor
                            //get rid of step children
                            for(parents=(children->children).PeekInit();parents!=NULL;parents=(children->children).PeekNext()){
                                if(parents!=NULL){
                                    if((parents->stepparents).FindObject(children->N_addr)){
                                        (parents->stepparents).RemoveCurrent();
                                    } else {
                                        //error statements shouldn't enter here
                                        if((parents->parents).FindObject(children->N_addr)){ qDebug() << "Error8\n";
                                            //              DMSG(0,"missing stepparents link for node %s to stepparent ",parents->N_addr.GetHostString());
                                            //              DMSG(0,"%s in LOST_LINKv4 area: /n",children->N_addr.GetHostString());
                                            //              DMSG(0,"but did find parent link! wasn't moved to stepparent correctly someplace in past!");
                                        } else { qDebug() << "Error9\n";
                                            //              DMSG(0,"missing stepparents link for node %s to stepparent ",parents->N_addr.GetHostString());
                                            //              DMSG(0,"%s in LOST_LINKv4 area: no parent link found",children->N_addr.GetHostString());
                                        }
                                        //end error stantments
                                    }
                                }
                            }
                            (children->children).Clear();
                            //get rid of step parents
                            for(parents=(children->stepparents).PeekInit();parents!=NULL;parents=(children->stepparents).PeekNext()){
                                if(parents!=NULL){
                                    //if(parents->N_addr.IPv4HostAddr()!=tuple_pt->N_addr.IPv4HostAddr()){
                                    if(parents->N_addr != tuple_pt->N_addr){
                                        if((parents->children).FindObject(children->N_addr)){
                                            (parents->children).RemoveCurrent();
                                        } else { qDebug() << "Error10\n";
                                            //              DMSG(0,"missing childlink for node %s to child ",parents->N_addr.GetHostString());
                                            //              DMSG(0,"%s in LOST_LINKv4 area: ",children->N_addr.GetHostString());
                                            //              DMSG(0,"%s stepparent was ",children->N_addr.GetHostString());
                                            //              DMSG(0,"%s\n",parents->N_addr.GetHostString());
                                        }
                                    }
                                }
                            }
                            (children->stepparents).Clear();
                            delete children;
                            //free(children);
                        }
                    }
                }
            }
            (tuple_pt->children).Clear();
            NbrTuple *mprtuple;
            if((mprtuple = mprSelectorList.FindObject(tuple_pt->N_addr))){
                mprSelectorList.RemoveCurrent();
                delete mprtuple;
                updateSmfForwardingInfo = true;  //send updated mpr selector list to send pipe if open
                //free(mprtuple);

            }
            //update current node
            if((tuple_pt->parents).IsEmpty()){ // has no parents can remain a 1 hop
                tuple_pt->hop=1;
            }
            else
                tuple_pt->hop=2;             // is now a 2 hop neighbor
            tuple_pt->N_time=InlineGetCurrentTime() + Neighb_Hold_Time;
            tuple_pt->N_status=ASYM_LINKv4;
            //tuple_pt->N_spf=spfValue;
            //tuple_pt->N_minmax=minmaxValue;
            tuple_pt->N_willingness = willingness;
            nbr_list.QueueObjectAddressSort(tuple_pt);
            //nbr_list.QueueObject(tuple_pt);
        }
    }
    return 1;
}

void Nrlolsr::update_mprselector(UINT32 id, int status) {
    //DMSG(6,"Enter: Nrlolsr::update_mprselector(id %s,int %d)\n",id.GetHostString(),status);
    //using the slighly bloated NBRQueue list for simple list
    NbrTuple *tuple_pt;
    switch(status){
    case SYM_LINKv4: // remove from list if there
        //DMSG(9,"in update_mprselector with SYM status for neighbor %s\n",id.GetHostString());
        tuple_pt=mprSelectorList.FindObject(id);
        if(tuple_pt){

            mprSelectorList.RemoveCurrent();
            delete tuple_pt;

            updateSmfForwardingInfo = true;  //send updated mpr selector list to send pipe if open

            //free(tuple_pt);
        }
        break;
    case MPR_LINKv4: // add to list if not there
        //DMSG(9,"in update_mprselector with MPR status for neighbor %s\n",id.GetHostString());
        tuple_pt=mprSelectorList.FindObject(id);
        if(!tuple_pt){


            //DMSG(7,"Adding neighbor %s to my mpr selctor list\n",id.GetHostString());
            tuple_pt=new NbrTuple;
            tuple_pt->N_addr=id;
            mprSelectorList.QueueObject(tuple_pt);

            updateSmfForwardingInfo = true;  //send updated mpr selector list to send pipe if open
        }
        break;
    }
    //DMSG(6,"Exit: Nrlolsr::update_mprselector(id %s,int %d)\n",id.GetHostString(),status);
}

void Nrlolsr::update_2hop_nbr(UINT32 onehop_addr, UINT32 twohop_addr){

    NbrTuple *tuple_pt,*parent_tuple_pt,*other_tuple_pt;
//    int updateMprs=0;
    int parentcheck=0;
//    int errortype=0;
    parent_tuple_pt=nbr_list.FindObject(onehop_addr);
    parentcheck=parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4;
    //printCurrentTable(3);
    //DMSG(10,"parent check %d \n",parentcheck);

    if((tuple_pt=nbr_2hop_list.FindObject(onehop_addr,twohop_addr))){ //returns two hop guy
        if(parentcheck){
            //DMSG(7,"found in correct link \n");
            fflush(stdout);
            //update time
            if((parent_tuple_pt=(tuple_pt->parents).FindObject(onehop_addr))){
                //	if(parent_tuple_pt=(tuple_pt->stepparents).FindObject(onehop_addr))
                //  DMSG(0,"both step parent and parent present how did it get this way?");
//                errortype=4;
                //DMSG(9,"real child \n",parent_tuple_pt);
                (tuple_pt->parents).RemoveCurrent(); // removes the pointer pointing to the parent so it can be updated
                //printCurrentTable(3);
                (tuple_pt->parents).QueueObject(parent_tuple_pt);
                //printCurrentTable(3);
                nbr_2hop_list.RemoveCurrent();
                nbr_2hop_list.QueueObject(tuple_pt);
            } else {
                // was a step child check to see if neighbor is true one hop
//                errortype=5;
                parent_tuple_pt=(tuple_pt->stepparents).FindObject(onehop_addr);
                //DMSG(9,"step child \n");
                (tuple_pt->stepparents).RemoveCurrent(); // removes the pointer pointing to the parent so it can be updated
                if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) {
//                    updateMprs=1;
                    (tuple_pt->parents).QueueObject(parent_tuple_pt);
                    nbr_2hop_list.RemoveCurrent();
                    nbr_2hop_list.QueueObject(tuple_pt);
                }	else {
                    (tuple_pt->stepparents).QueueObject(parent_tuple_pt);
                }
            }
            other_tuple_pt=(parent_tuple_pt->children).FindObject(twohop_addr);
            //DMSG(11,"%p %p should be the same \n",tuple_pt,other_tuple_pt);
            fflush(stdout);
            (parent_tuple_pt->children).RemoveCurrent(); // removes the pointer pointing to the child so it can be updated
            (parent_tuple_pt->children).QueueObject(other_tuple_pt);  // updating the time again
        }
    } else if((tuple_pt=nbr_2hop_list.FindObject(twohop_addr))){
        //is already someones two hop neighbor just link them together
        //DMSG(8,"is an existing 2 hop neighbor \n");
        if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) { //make sure neighbor is true one hop
//            errortype=6;
//            updateMprs=1;
            (tuple_pt->parents).QueueObject(parent_tuple_pt); // link child to parent node
            nbr_2hop_list.RemoveCurrent();  // next two lines update the timeout value of the 2 hop neighbor
            nbr_2hop_list.QueueObject(tuple_pt);
        } else {
//            errortype=7;
            (tuple_pt->stepparents).QueueObject(parent_tuple_pt); //link child to node which isn't a real one hop node yet
        }
        (parent_tuple_pt->children).QueueObject(tuple_pt); // link parent to child node
    } else if((tuple_pt=nbr_list.FindObject(twohop_addr))){
        //is already a one hop neighbor just link them together
        //DMSG(7,"is an existing 1 hop neighbor \n");
        //DMSG(7,"parent_tuple_pt->N_status=%d mpr=%d sym=%d\n",parent_tuple_pt->N_status,MPR_LINKv4,SYM_LINKv4);
        if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) { //make sure neighbor is true one hop
//            errortype=8;
//            updateMprs=1;
            (tuple_pt->parents).QueueObject(parent_tuple_pt); // link the child to parent node
            //DMSG(7,"Adding 2hop neighbor %s to ",parent_tuple_pt->N_addr.GetHostString());
            //DMSG(7,"%s to neighbor table now\n",tuple_pt->N_addr.GetHostString());
            nbr_2hop_list.QueueObject(tuple_pt); // add to two hop list
            (parent_tuple_pt->children).QueueObject(tuple_pt); // link the parent to the child node
        } else {
            //do nothing not a real neighbor yet
//            errortype=9;
        }
    }
    else {
        //DMSG(8,"should be true one hop neighbor \n");
        //DMSG(8,"parent_tuple_pt->N_status = %d MPR_linkv4 = %d SYM_LINKv4 = %d\n",parent_tuple_pt->N_status,MPR_LINKv4,SYM_LINKv4);
        if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) { //make sure neighbor is true one hop
//            errortype=10;
            //no existing 2 hop neighbor with given twohop_addr
            // make and link them together
            //DMSG(7,"Adding and making two hop neighbor %s to ",twohop_addr.GetHostString());
            //DMSG(7,"%s\n",parent_tuple_pt->N_addr.GetHostString());

//            updateMprs=1;
            tuple_pt=new NbrTuple; // make new neighbor
            tuple_pt->N_addr=twohop_addr;
            tuple_pt->hop=2;
            (tuple_pt->parents).QueueObject(parent_tuple_pt);// link child to parent node
            (parent_tuple_pt->children).QueueObject(tuple_pt); // link parent to child node
            nbr_2hop_list.QueueObject(tuple_pt);  // add to two hop list
            //tuple_pt is only valid for use as a 2 hop right now the queue time is not set up properly as Vtime for it is not known
        }
        else{
//            errortype=11;
            // may make node and add to stepparents in the future
            //DMSG(8,"ignroing 2 link cause 1 hop is pending \n");
        }

    }
    //checkCurrentTable(errortype);
    //printCurrentTable(3);
}//end Nrlolsr::update_2hop_nbr(onehop,twohop)

void Nrlolsr::update_2hop_nbrExtra(UINT32 onehop_addr, UINT32 twohop_addr, unsigned long nodedegree){
    //DMSG(6,"Enter: Nrlolsr::update_2hop_nbr(onehop %s,twohop",onehop_addr.GetHostString());
    //DMSG(6," %s\n",twohop_addr.GetHostString());

    NbrTuple *tuple_pt,*parent_tuple_pt,*other_tuple_pt;
//    int updateMprs=0;
    int parentcheck=0;
//    int errortype=0;
    parent_tuple_pt=nbr_list.FindObject(onehop_addr);
    parentcheck=parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4;
    //printCurrentTable(3);
    //DMSG(10,"parent check %d \n",parentcheck);

    if((tuple_pt=nbr_2hop_list.FindObject(onehop_addr,twohop_addr))){ //returns two hop guy
        tuple_pt->node_degree=nodedegree;
        if(parentcheck){
            //DMSG(8,"found in correct link \n");
            fflush(stdout);
            //update time
            if((parent_tuple_pt=(tuple_pt->parents).FindObject(onehop_addr))){
                //	if(parent_tuple_pt=(tuple_pt->stepparents).FindObject(onehop_addr))
                //  DMSG(0,"both step parent and parent present how did it get this way?");
//                errortype=4;
                //DMSG(9,"real child \n",parent_tuple_pt);
                (tuple_pt->parents).RemoveCurrent(); // removes the pointer pointing to the parent so it can be updated
                //printCurrentTable(3);
                (tuple_pt->parents).QueueObject(parent_tuple_pt);
                //printCurrentTable(3);
                nbr_2hop_list.RemoveCurrent();
                nbr_2hop_list.QueueObject(tuple_pt);
            }
            else {
                // was a step child check to see if neighbor is true one hop
//                errortype=5;
                parent_tuple_pt=(tuple_pt->stepparents).FindObject(onehop_addr);
                //DMSG(9,"step child \n");
                (tuple_pt->stepparents).RemoveCurrent(); // removes the pointer pointing to the parent so it can be updated
                if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) {
//                    updateMprs=1;
                    (tuple_pt->parents).QueueObject(parent_tuple_pt);
                    nbr_2hop_list.RemoveCurrent();
                    nbr_2hop_list.QueueObject(tuple_pt);
                }
                else {
                    (tuple_pt->stepparents).QueueObject(parent_tuple_pt);
                }
            }
            other_tuple_pt=(parent_tuple_pt->children).FindObject(twohop_addr);
            //DMSG(11,"%p %p should be the same \n",tuple_pt,other_tuple_pt);
            fflush(stdout);
            (parent_tuple_pt->children).RemoveCurrent(); // removes the pointer pointing to the child so it can be updated
            (parent_tuple_pt->children).QueueObject(other_tuple_pt);  // updating the time again
        }
    }
    else if((tuple_pt=nbr_2hop_list.FindObject(twohop_addr))){
        //is already someones two hop neighbor just link them together
        //DMSG(8,"is an existing 2 hop neighbor \n");
        if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) { //make sure neighbor is true one hop
//            errortype=6;
//            updateMprs=1;
            (tuple_pt->parents).QueueObject(parent_tuple_pt); // link child to parent node
            nbr_2hop_list.RemoveCurrent();  // next two lines update the timeout value of the 2 hop neighbor
            nbr_2hop_list.QueueObject(tuple_pt);
        } else {
//            errortype=7;
            (tuple_pt->stepparents).QueueObject(parent_tuple_pt); //link child to node which isn't a real one hop node yet
        }
        (parent_tuple_pt->children).QueueObject(tuple_pt); // link parent to child node
    }
    else if((tuple_pt=nbr_list.FindObject(twohop_addr))){
        //is already a one hop neighbor just link them together
        //DMSG(8,"is an existing 1 hop neighbor \n");
        //DMSG(8,"parent_tuple_pt->N_status=%d mpr=%d sym=%d\n",parent_tuple_pt->N_status,MPR_LINKv4,SYM_LINKv4);
        if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) { //make sure neighbor is true one hop
//            errortype=8;
//            updateMprs=1;
            (tuple_pt->parents).QueueObject(parent_tuple_pt); // link the child to parent node
            //DMSG(7,"Adding 2hop neighbor %s to ",parent_tuple_pt->N_addr.GetHostString());
            //DMSG(7,"%s to neighbor table now\n",tuple_pt->N_addr.GetHostString());
            nbr_2hop_list.QueueObject(tuple_pt); // add to two hop list
            (parent_tuple_pt->children).QueueObject(tuple_pt); // link the parent to the child node
        } else {
            //do nothing not a real neighbor yet
//            errortype=9;
        }
    }
    else {
        //DMSG(8,"should be true one hop neighbor \n");
        //DMSG(8,"parent_tuple_pt->N_status = %d MPR_linkv4 = %d SYM_LINKv4 = %d\n",parent_tuple_pt->N_status,MPR_LINKv4,SYM_LINKv4);
        if(parent_tuple_pt->N_status==MPR_LINKv4 || parent_tuple_pt->N_status==SYM_LINKv4) { //make sure neighbor is true one hop
//            errortype=10;
            //no existing 2 hop neighbor with given twohop_addr
            // make and link them together
            //DMSG(7,"Adding and making two hop neighbor %s to ",twohop_addr.GetHostString());
            //DMSG(7,"%s\n",parent_tuple_pt->N_addr.GetHostString());

//            updateMprs=1;
            tuple_pt=new NbrTuple; // make new neighbor
            tuple_pt->N_addr=twohop_addr;
            tuple_pt->hop=2;
            tuple_pt->node_degree=nodedegree;
            (tuple_pt->parents).QueueObject(parent_tuple_pt);// link child to parent node
            (parent_tuple_pt->children).QueueObject(tuple_pt); // link parent to child node
            nbr_2hop_list.QueueObject(tuple_pt);  // add to two hop list
            //tuple_pt is only valid for use as a 2 hop right now the queue time is not set up properly as Vtime for it is not known
        }
        else{
//            errortype=11;
            // may make node and add to stepparents in the future
            //DMSG(8,"ignroing 2 link cause 1 hop is pending \n");
        }

    }
    //checkCurrentTable(errortype);
    //printCurrentTable(3);
}//end Nrlolsr::update_2hop_nbr(onehop,twohop)

void
Nrlolsr::remove_2hop_link(UINT32 oneaddr, UINT32 twoaddr){
    NbrTuple *tuple_pt, *child_pt, *parents;
    tuple_pt=nbr_list.FindObject(oneaddr);
    if(tuple_pt){ //should always pass
        child_pt=tuple_pt->children.FindObject(twoaddr);
        if(child_pt){ // should pass most of the time
            //DMSG(7,"Removing: 2 hop neighbor %s ",twoaddr.GetHostString());
            //DMSG(7,"two %s\n",oneaddr.GetHostString());
            // remove the link
            if((tuple_pt=child_pt->parents.FindObject(oneaddr))){ // check if its a parent or step parent
                child_pt->parents.RemoveCurrent();
            }
            else if((tuple_pt=child_pt->stepparents.FindObject(oneaddr))){
                child_pt->stepparents.RemoveCurrent();
            } else {
                //    DMSG(0,"parent checking failed in remove_2hop_link! %s to %s at time %f \n",oneaddr.GetHostString(),twoaddr.GetHostString(),InlineGetCurrentTime());
            }
            tuple_pt->children.RemoveCurrent();
            // check to see if child lost last parent
            if(child_pt->parents.IsEmpty()){
                // lost last parent remove the node
                if(nbr_2hop_list.FindObject(twoaddr)) // may have been a stepparent removed
                    nbr_2hop_list.RemoveCurrent();
                if(!nbr_list.FindObject(twoaddr)){ //check to see if it was exclusivly a 2 hop neighbor
                    //get rid of step parents of removed node
                    for(parents=((child_pt->stepparents).PeekInit());parents!=NULL;parents=(child_pt->stepparents).PeekNext()){
                        if(parents!=NULL){
                            if(parents->N_addr != tuple_pt->N_addr){
                                //if(parents->N_addr.IPv4HostAddr()!=tuple_pt->N_addr.IPv4HostAddr()){ //will neverhappen removed above
                                if((parents->children).FindObject(child_pt->N_addr)) {
                                    (parents->children).RemoveCurrent();
                                } else { qDebug() << "Error10.5\n";
                                    //          DMSG(0,"missing childlink for node %s to child ",parents->N_addr.GetHostString());
                                    //          DMSG(0,"%s in remove_2hop_link area: ",child_pt->N_addr.GetHostString());
                                    //          DMSG(0,"%s stepparent was ",child_pt->N_addr.GetHostString());
                                    //          DMSG(0,"%s\n",parents->N_addr.GetHostString());
                                }
                            }
                        }
                    }
                    (child_pt->stepparents).Clear();
                    //get rid of step children of removed node
                    for(parents=((child_pt->children).PeekInit());parents!=NULL;parents=(child_pt->children).PeekNext()){
                        if(parents!=NULL){
                            if((parents->stepparents).FindObject(child_pt->N_addr)){
                                (parents->stepparents).RemoveCurrent();
                            } else {
                                //error statments shouldn't enter here
                                if((parents->parents).FindObject(child_pt->N_addr)){ qDebug() << "Error11\n";
                                    //          DMSG(0,"missing stepparents link for node %s to stepparent ",parents->N_addr.GetHostString());
                                    //          DMSG(0,"%s in remove_2hop_link area: /n ",child_pt->N_addr.GetHostString());
                                    //          DMSG(0,"but did find parent link! wasn't moved to stepparent correctly someplace in the past!");
                                } else { qDebug() << "Error12\n";
                                    //          DMSG(0,"missing stepparents link for the node %s to stepparents ",parents->N_addr.GetHostString());
                                    //          DMSG(0,"%s in remove_2hop_link area: no parent link found",child_pt->N_addr.GetHostString());
                                }
                                // end error statements
                            }
                        }
                    }
                    (child_pt->children).Clear();
                    delete child_pt;
                    //free(child_pt);
                }
            }
        } else {
            // DMSG(0,"child_pt %d not found in tuple_pt %d's child list whild trying to remove in remove_2hop_link at time %f for node %d",twoaddr,oneaddr,InlineGetCurrentTime(),here_.addr_);
        }
    } else { qDebug() << "Error13\n";
        //    DMSG(0,"tuple_pt not found in nbr_list, trying to remove two hop %s to ",oneaddr.GetHostString());
        //    DMSG(0,"%s at time %f link doesn't exist!",twoaddr.GetHostString(),InlineGetCurrentTime());
    }
    //checkCurrentTable(40);
}
//end remove_2hop_link(oneaddr,twoaddr)

bool Nrlolsr::NeighborsStableForHello(){
    //check old neighbor table against current table
    bool returnvalue=true;
    NbrTuple *nb=NULL;
    NbrTuple *nbold=nbr_list_old_for_hello.PeekInit();
    if (!nbold){
        returnvalue=false;
    }
    //  DMSG(6,"%p\n",nbold);
    for(nb=nbr_list.PrintPeekInit();(nb!=NULL) && returnvalue;nb=nbr_list.PrintPeekNext()){
        if(nbold && nb){//entries still exist in both tables
            if(nbold->N_addr != nb->N_addr || nbold->N_status!=nb->N_status){//entries are not the same
                returnvalue = false;
            } else {
                nbr_list_old_for_hello.RemoveCurrent();
                delete nbold;
                nbold=nbr_list_old_for_hello.PeekInit();
            }
        } else if ( nbold || nb) { //one table still has an entry and the other does not so they are not the same
            returnvalue=false;
        }
    }
    //make sure the old list is completly cleaned up
    nbold=nbr_list_old_for_hello.PeekInit();
    while(nbold){
        nbr_list_old_for_hello.RemoveCurrent();
        delete nbold;
        nbold=nbr_list_old_for_hello.PeekInit();
    }
    //copy current table into old neighbor table
    for(nb=nbr_list.PrintPeekInit();(nb!=NULL);nb=nbr_list.PrintPeekNext()){
        if(nb){
            nbold=new NbrTuple;
            nbold->N_addr=nb->N_addr;
            nbold->N_status=nb->N_status;
            nbr_list_old_for_hello.QueueObjectAddressSort(nbold);
        }
    }
    return returnvalue;
}


// when making a new routing table first the old table is stored.  Then the new one is made all new from the valid topology,
// and neighbor tables.  Then routes are added or changed depending on if they are new or not.  Then entries in the old
// routing table which are not coverd yet are removed.  The method on how to create a routing table is covered in the OLSR
// specification.  One interteresting point to mention is that the way the lists of the tables are ordered makes a difference
// in the outcome of the resulting routing table.
void Nrlolsr::makeNewRoutingTable(){
    //DMSG(6,"Enter: Nrlolsr::makeNewRoutingTable()\n");
    //  printCurrentTable(/*3*/);


    NbrTuple *nb, *nb2=NULL, *top_tuple, *old_tuple, *tuple = routeTable.PeekInit();
    int wasnewentry=0, queueIndex=0,foundnewlink=0;
    double smallestSpf=0 ;
    //  printRoutingTable(2);
    //clearing old routing table
    oldRouteTable.Clear();
    while(tuple){
        routeTable.RemoveCurrent();
        //DMSG(10,"copying entry in routing table to extra queue \n");
        oldRouteTable.QueueObject(tuple);
        tuple=routeTable.PeekInit();
    }

    //fix up lists which are used for output/printing purposes
    routeNeighborSet.Clear();

    // making new queue to use
    extraQueue.Clear();

    //adding one hops
    for(nb=nbr_list.PeekInit();nb!=NULL;nb=nbr_list.PeekNext()){
        if(nb!=NULL){
            if((nb->N_status==SYM_LINKv4 || nb->N_status==MPR_LINKv4) && nb->N_macstatus!=LINK_DOWN){
                tuple=new NbrTuple;
                tuple->N_time=queueIndex--; //used queue object at head (which is faster way)
                tuple->N_addr=nb->N_addr;  // really R_dest
                tuple->N_2hop_addr=nb->N_addr; // really R_next
                tuple->hop=1;                    // really R_dist
                tuple->N_status=-1;
                routeTable.QueueObject(tuple);
                wasnewentry=1;
                // removing links pointing to this node
                for(top_tuple=extraQueue.PeekInit();top_tuple!=NULL;top_tuple=extraQueue.PeekNext()){
                    if(top_tuple->N_2hop_addr == tuple->N_addr){
                        extraQueue.RemoveCurrent();
                    }
                }
                routeNeighborSet.QueueObject(nb);
            }
        }
    }
    int shortesthop=5000;
    while(wasnewentry){
        //add on smallest value nodes
        wasnewentry=0;
        foundnewlink=0;
        shortesthop=5000;
        for(top_tuple=extraQueue.PeekInit();(top_tuple!=NULL);top_tuple=extraQueue.PeekNext()){
            for(tuple=routeTable.PeekInit();(tuple!=NULL);tuple=routeTable.PeekNext()){
                if(top_tuple->N_addr == tuple->N_addr && top_tuple->N_2hop_addr != myaddress){ //T_last==R_dest | doesn't point back to here | delay is smaller
                    if(tuple->hop+1<shortesthop){//found new shortest hop node
                        shortesthop=tuple->hop+1;
                        nb=tuple;
                        nb2=top_tuple;
                        foundnewlink=1;
                    }
                }
            }
        }
        if(foundnewlink){
            // add the link nb to routing table and do over again
            //printRoutingTable(3);
            wasnewentry=1;
            tuple = new NbrTuple;
            tuple->N_time=queueIndex--;
            tuple->N_addr=nb2->N_2hop_addr;  //is R_dest=T_dest
            tuple->N_2hop_addr=nb->N_2hop_addr;       //is R_next=R_next
            tuple->N_spf=(UINT8)(smallestSpf*(double)OLSRMAXSPF);
            tuple->hop=nb->hop+1;
            tuple->N_status=0;
            routeTable.QueueObject(tuple);
            //have to remove from extraQueue tuples point at node just added
            for(top_tuple=extraQueue.PeekInit();top_tuple!=NULL;top_tuple=extraQueue.PeekNext()){
                if(top_tuple->N_2hop_addr == nb2->N_2hop_addr){
                    extraQueue.RemoveCurrent();
                }
            }
//                  routeTopologySet.QueueObject(nb2); //add topolgy tuple which was used for this route to the list of links used in route calculation
        }
    }

    // go though and cleanly update the real routing table
    //add direct routes first
    for(tuple=routeTable.PeekInit();tuple!=NULL;tuple=routeTable.PeekNext()){
        if(tuple->N_addr == tuple->N_2hop_addr){ //only do direct routes in the section
            if((old_tuple = oldRouteTable.FindObject(tuple->N_addr))){
                //old host route existed check to see if current choice is different
                if(old_tuple->N_2hop_addr != tuple->N_2hop_addr){// if the gateways are differnet change the route (old one was host route)
                    realRouteTable.SetRoute(tuple->N_addr,invalidAddress,interfaceIndex,tuple->hop);
                } else {
                    //      DMSG(4,"Not changing direct route to %s\n",tuple->N_addr.GetHostString());
                }
                oldRouteTable.RemoveCurrent();
                delete old_tuple;

            } else {
                //old host route did not exist just add to real table
                realRouteTable.SetRoute(tuple->N_addr,invalidAddress,interfaceIndex,tuple->hop);
            }
        }
    }
    //add host routes second
    for(tuple=routeTable.PeekInit();tuple!=NULL;tuple=routeTable.PeekNext()){
        if(tuple->N_addr != tuple->N_2hop_addr){ //check to make sure is a host route
            if((old_tuple = oldRouteTable.FindObject(tuple->N_addr))){
                //old route existed for current host route
                if(old_tuple->N_2hop_addr != tuple->N_2hop_addr){// if the gateways are differnet change the route
                    realRouteTable.SetRoute(tuple->N_addr,tuple->N_2hop_addr,interfaceIndex,tuple->hop);
                } else {
                    //      DMSG(4,"Not changing host route to %s via",tuple->N_addr.GetHostString());
                    //      DMSG(4," %s\n",tuple->N_2hop_addr.GetHostString());
                }
                oldRouteTable.RemoveCurrent();
                delete old_tuple;
            } else {
                //old host route did not exist just add to real table
                realRouteTable.SetRoute(tuple->N_addr,tuple->N_2hop_addr,interfaceIndex,tuple->hop);
            }
        }
    }
    old_tuple=oldRouteTable.PeekInit();
    while(old_tuple){ //loop to clean extraQueue and remove old routes
        oldRouteTable.RemoveCurrent();
        if(old_tuple->N_addr == old_tuple->N_2hop_addr){
            if(!realRouteTable.DeleteRoute(old_tuple->N_addr,invalidAddress/*,interfaceIndex*/)){
                qDebug() << "Nrlolsr::makeNewRoutingTable() Error removing direct route to " << old_tuple->N_addr << "\n";
            }
        } else {
            if(!realRouteTable.DeleteRoute(old_tuple->N_addr,old_tuple->N_2hop_addr/*,interfaceIndex*/)){
                qDebug() << "Nrlolsr::makeNewRoutingTable() Error removing host route to " << old_tuple->N_addr << " via " << old_tuple->N_2hop_addr << endl;
            }
        }
        delete old_tuple;
        //free(old_tuple);
        old_tuple=oldRouteTable.PeekInit();
    }
    //  DMSG(4,"Finished updating %s's route table\n",myaddress.GetHostString());
}
//end Nrlolsr::makeNewRoutingTable()


void Nrlolsr::printRoutingTable(/*int debuglvl*/){
    //  if(olsrDebugValue>=debuglvl){
    int numberofroutes=0;
    NbrTuple *tuple;
    qDebug() << "------- " << myaddress << "'s routing table at time " << InlineGetCurrentTime() << " --------\n";
    for(tuple=routeTable.PrintPeekInit();tuple!=NULL;tuple=routeTable.PrintPeekNext()){
        if(tuple!=NULL){
            numberofroutes++;
            qDebug() << " R_dest= " << tuple->N_addr << " R_gw= " << tuple->N_2hop_addr << " R_m= " << tuple->hop;
        }
    }
    qDebug() << "------- end " << myaddress << "'s routing table with " << numberofroutes << " entries at time " << InlineGetCurrentTime() << "-------- \n";
    //  }
}


void Nrlolsr::printCurrentTable(/*int debuglvl*/){
    //  if(olsrDebugValue>=debuglvl){
    int number_of_nbrs=0;
    int number_of_2hop_nbrs=0;
    NbrTuple *nb;//,*nb2;
    qDebug() << " === " << myaddress << " nbr table at time " << InlineGetCurrentTime() << " === \n1hop:";
    for(nb=nbr_list.PrintPeekInit();nb!=NULL;nb=nbr_list.PrintPeekNext()){
        if(nb!=NULL){
            number_of_nbrs++;
            qDebug() << ":" << nb->N_addr << " " << nb->hop << " " << nb->N_status << " " << nb->konectivity << endl;
        }
    }
    qDebug() << "\n2hop:";
    for(nb=nbr_2hop_list.PrintPeekInit();nb!=NULL;nb=nbr_2hop_list.PrintPeekNext()){
        if(nb!=NULL){
            if(nb->hop==2){
                number_of_2hop_nbrs++;
                qDebug() << nb->N_2hop_addr << ' ' << nb->hop << ' ' << nb->N_status << ' ' << nb->konectivity << ' ' << nb->N_addr << endl;
            }
        }
    }
    qDebug() << "\n ==== end " << myaddress << " nbr table === #nbrs = " << number_of_nbrs << " #2hopnbrs = " << number_of_2hop_nbrs << " ====\n";
    //  }
}
// end PrintCurrentTable

//TBIs here
bool Nrlolsr::OnHelloTimeout(/*ProtoTimer& theTimer*/)
{
    //  DMSG(6,"Enter: Nrlolsr::OnHelloTimeout(theTimer)\n");

    //do hello timer stuff
    if(sendHelloTimerOn){
//        if(hello_jitter_timer.isActive()){
//            emit StopTimer();
//            hello_jitter_timer.stop();
//        }
        sendHelloTimerOn=false;
        qDebug() << "Sending HELLO...\n";
        SendHello();
    } else {
        qDebug() << "Not sending HELLO...\n";
        printCurrentTable(/*3*/);

        printRoutingTable(/*3*/);
        // do periodic checking here
        // instead of using the packet numbers to see if a packet was lost durring a hello interval to update the historisis
        // I decided thatt it would be easier and more active if it checked for lost packets every hello interval but given the
        // nature of the jitter in the hello interavl the konectivity value for a node is only started to be reduced after 2 of its
        // hello intervals with no recieved message from that node.  the way the jitter is implimented in this code at most 3 hello's
        // can be recieved in any given interval (and that rarely) so that the one sending hellos faster can fake at most 2 lost
        // hello messages.  if a hello is percieved as no being there a flag is rasied if then the next hello interval there is still
        // no reply for the missing neighbor its konectivity value is decreased with the factor alpha

        NbrTuple *nb;
        for(nb=nbr_list.PeekInit();nb!=NULL;nb=nbr_list.PeekNext()){//qDebug() << "POOPING SHIT!!!!!!";
            if(nb!=NULL){
                if(nb->recievedHello>0){
                    qDebug() << "From " << nb->N_addr << " recieved hello\n";
                    nb->recievedHello=0;
                } else if(nb->recievedHello==0) {
                    qDebug() << "From " << nb->N_addr << " did not recieve hello\n";
                    nb->recievedHello=-1;
                } else if(nb->recievedHello==-1) {
                    qDebug() << "From " << nb->N_addr << " did not recieve several hellos\n";
                    nb->konectivity=nb->konectivity*alpha; // reduce value
                }
            }
        }
        //end periodic checking

        //set up next timer to send packet out
        sendHelloTimerOn=true;
        double randValue = UniformRand(Hello_Interval)*Hello_Jitter;// + Hello_Interval * (1 - Hello_Jitter);
//        hello_jitter_timer.setInterval(randValue);
//        hello_jitter_timer.start();
        emit StartTimer(randValue);
    }
    //    DMSG(6,"Exit: Nrlolsr::OnHelloTimeout(theTimer)\n");
    return true;
}
// end Nrlolsr::OnHellotimeout()


//TBIs here
bool Nrlolsr::SendHello()
{
    qDebug() << QString("Enter: Nrlolsr::SendHello() at time %1\n").arg(InlineGetCurrentTime());
    //this method will build and send a hello packet when called it uses methods defined in the olsr_packet_types.h file

    //clean up tables
    nb_purge();
    dup_purge();
    makeNewRoutingTable();

    //TBI  printLinks();
    //  printRouteLinks();
    //  printNbrs();
      selectmpr(); //make sure mprs are up to date before building packet

    seqno++;

    //build up parts for adding to hello message
    LinkMessage asymlinks, symlinks, mprlinks, lostlinks;
    asymlinks.linkCode=ASYM_LINKv4;
    asymlinks.reserved=0;

    symlinks.linkCode=SYM_LINKv4;
    symlinks.reserved=0;

    mprlinks.linkCode=MPR_LINKv4;
    mprlinks.reserved=0;

    lostlinks.linkCode=LOST_LINKv4;
    lostlinks.reserved=0;

    //actually add the links to their type lists
    NbrTuple *nb;
    //  localNodeDegree=0;
    for(nb=nbr_list.PeekInit();nb!=NULL;nb=nbr_list.PeekNext()){
        if(nb!=NULL){
            if(nb->N_macstatus==LINK_DEFAULT) { //olsr state of neighbors is used
                if(nb->N_time>InlineGetCurrentTime()){
                    if(nb->N_status==ASYM_LINKv4){
                        asymlinks.addNeighbor(nb->N_addr);
                    }
                    if(nb->N_status==SYM_LINKv4){
                        //        if(floodingType==ECDS){
                        //          localNodeDegree++;
                        //          symlinks.addNeighborExtra(&nb->N_addr,nb->node_degree);
                        //        } else {
                        symlinks.addNeighbor(nb->N_addr);
                        //        }
                    }
                    if(nb->N_status==MPR_LINKv4){
                        //        if(floodingType==ECDS){
                        //          localNodeDegree++;
                        //          mprlinks.addNeighborExtra(&nb->N_addr,nb->node_degree);
                        //        } else {
                        mprlinks.addNeighbor(nb->N_addr);
                        //        }
                    }
                    if(nb->N_status==LOST_LINKv4){
                        nb->N_status=PENDING_LINK; //move back to pending link type
                        lostlinks.addNeighbor(nb->N_addr);
                    }
                }
            } else if (nb->N_macstatus==LINK_UP) {
                if(nb->N_status==MPR_LINKv4){ //link is always up no matter the olsr state either mpr or sym
                    //      if(floodingType==ECDS){
                    //        localNodeDegree++;
                    //        mprlinks.addNeighborExtra(&nb->N_addr,nb->node_degree);
                    //      } else {
                    mprlinks.addNeighbor(nb->N_addr);
                    //      }
                } else {
                    //      if(floodingType==ECDS){
                    //        localNodeDegree++;
                    //        symlinks.addNeighborExtra(&nb->N_addr,nb->node_degree);
                    //      } else {
                    symlinks.addNeighbor(nb->N_addr);
                    //      }
                }
            } else if (nb->N_macstatus==LINK_DOWN) {
                lostlinks.addNeighbor(nb->N_addr); //keep sending that the link is lost
            }
        }
    }
    //  DMSG(4,"size of link messages ASYM=%d | SYM=%d | MPR=%d LOST=%d\n",asymlinks.size,symlinks.size,mprlinks.size,lostlinks.size);

    // build up whole hello message
    HelloMessage hellomessage;
    hellomessage.htime = Mantissa_Hello_Interval; //this value is not currently processed upon being recieved.
    hellomessage.willingness = localWillingness;
    hellomessage.addLinkMessage(&symlinks);
    hellomessage.addLinkMessage(&mprlinks);
    hellomessage.addLinkMessage(&lostlinks);
    hellomessage.addLinkMessage(&asymlinks);
    //DMSG(4,"%d is size of hello message\n",hellomessage.size);

    // build up Olsr message
    OlsrMessage olsrmessage;
    olsrmessage.type=NRLOLSR_HELLO;
    olsrmessage.Vtime = doubletomantissa(Neighb_Hold_Time);
    olsrmessage.SetO_addr(myaddress);
    olsrmessage.ttl=1;
    olsrmessage.D_seq_num=seqno;
    olsrmessage.setHelloMessage(&hellomessage);

    DelayedForward(&olsrmessage);//will add hello to packet and send out right away

    return true;
}
// end Nrlolsr::SendHello()


//TBIs here
void Nrlolsr::DelayedForward(OlsrMessage *forwardmessage){
    //  DMSG(6,"Enter: Nrlolsr::DelayedForward(OlsrMessage *forwardmessage,double delay)\n");
    if(forwardmessage->O_addr != myaddress){ //only decrement ttl and hopc if messages was not originated by myaddress
        forwardmessage->ttl--;
        forwardmessage->hopc++;
    }
    //OlsrPacket olsrpacket2forward;
    olsrpacket2forward.addOlsrMessage(forwardmessage);

    char forwardbuffer[1500];
    int forwardbuffersize=olsrpacket2forward.pack(forwardbuffer,1500);
    unsigned int forwardlen = forwardbuffersize;

    //TBI        if(forwardlen<helloPadding && forwardmessage->type==NRLOLSR_HELLO){
    //          //last message added to the packet was a hello and padding level is greater than then buffer length.
    //          forwardlen=helloPadding;
    //          memset((void*)(forwardbuffer+forwardbuffersize),helloPadding-forwardbuffersize,0);
    //        }

    QByteArray data(forwardbuffer, forwardlen);

    SendRoutingData(data);
    //    socket.SetTTL(1);
    //    socket.SendTo(forwardbuffer,forwardlen,broadAddr);
    olsrpacket2forward.clear();
    olsrpacket2forward.seqno=pseqno++;
//    }
}
// end Nrlolsr::DelayedForward

bool Nrlolsr::SendRoutingData(QByteArray &data)
{
    if (interfaceIndex == INTERFACE_COM)
        return serialPortHandler.SendData(data);
    else if (interfaceIndex == INTERFACE_UDP)
        return udpSocketHandler.SendData(data);
    qDebug() << "interfaceIndex is not defined!";
    return false;
}

// a bit convoluted because of the historisis  there are 2 checks in some areas to see
// which type of timeout is occuring historisis or complete timeout and removal
// if a historisis disconnect occurs it deleats 2 hop neighbors and makes it a lost neighbor
// the node will switch the lost_link to pending_link after sending out lost link message.
// checks each one hop neighbor and then checks all of there childrens timeout values
// if a one hop neighbor is removed all of its 2 hop links are also removed and it may be
// deleated or moved to the 2 hop list if a valid link is still up

void Nrlolsr::nb_purge() {
    //DMSG(6,"Enter: Nrlolsr::nb_purge()\n");
    NbrTuple *nb,*nbold=NULL, *children, *parents;
    int nbfree=0;
//    int mprupdate=0;
    //int redoRoutes=0;// used when manually taking out topology tuples due to historisis
    //  DMSG(6,"Enter: nb_purge() for %s \n",myaddress.GetHostString());

    //printCurrentTable(3);
    for(nb=nbr_list.PeekInit();nb!=NULL;nb=nbr_list.PeekNext()){
        if(nb!=NULL){ // is a valid pointer
            //      DMSG(8,"%f is hystersis value of %s. upvalue=%f downvalue=%f at time %f time\n",nb->konectivity,nb->N_addr.GetHostString(),T_up,T_down,nb->N_time);
            if(nb->N_macstatus!=LINK_UP && nb->konectivity<T_down && (nb->N_status==SYM_LINKv4 || nb->N_status==MPR_LINKv4 || nb->N_status==ASYM_LINKv4))
            { // check to see if historisis link failure occured
                //    DMSG(4,"local link %s to ",myaddress.GetHostString());
                //    DMSG(4,"%s is broken\n",nb->N_addr.GetHostString());
                nb->N_status=LOST_LINKv4;

            }
            if(nb->N_macstatus!=LINK_UP && (nb->N_time<InlineGetCurrentTime() || nb->N_status==LOST_LINKv4)){ //check to see if link expired b/c normal timeout
//                mprupdate=1;
                fflush(stdout);
                if(nb->N_time<InlineGetCurrentTime()){ //get rid of one hop neighbor as well
                    //      DMSG(7,"Removing nb %s ",nb->N_addr.GetHostString());
                    //      DMSG(7,"from %s's list at time %f cause %f timeout\n",myaddress.GetHostString(),InlineGetCurrentTime(),nb->N_time);
                    nbr_list.RemoveCurrent();
                }
                //removing children from parent/stepparent node that is being deleated
                for(children=(nb->children).PeekInit();children!=NULL;children=(nb->children).PeekNext()){
                    if(children!=NULL){
                        //abandon children
                        if((children->parents).FindObject(nb->N_addr)){
                            (children->parents).RemoveCurrent();
                        } else if((children->stepparents).FindObject(nb->N_addr)){
                            (children->stepparents).RemoveCurrent();
                        } else {
                            qDebug() << "child without parent or stepparent pointer in nb_purge | ";
                        }
                        if((children->parents).IsEmpty()){
                            //child lost last parent, child runs free
                            ////DMSG(1,"removing 2 hop %d cause %d deleated from %d's 1 hop list (purge)\n",children->N_addr,nb->N_addr,myaddress.IPv4HostAddr());
                            // DMSG(7,"Removing 2 hop %s ",children->N_addr.GetHostString());
                            //DMSG(7,"cause %s deleated from ",nb->N_addr.GetHostString());
                            //DMSG(7,"%s's 1 hop list (purge)\n",myaddress.GetHostString());
                            if(nbr_2hop_list.FindObject(children->N_addr))
                                nbr_2hop_list.RemoveCurrent();
                            if(!nbr_list.FindObject(children->N_addr)){ //check to see if it was exclusivly a 2 hop neighbor
                                ////DMSG(1,"testline 0 \n");
                                //DMSG(12,"testline 0 \n");
                                //get rid of step children
                                for(parents=(children->children).PeekInit();parents!=NULL;parents=(children->children).PeekNext()){
                                    if(parents!=NULL){
                                        if((parents->stepparents).FindObject(children->N_addr)){
                                            (parents->stepparents).RemoveCurrent();
                                        } else if((parents->parents).FindObject(children->N_addr)){
                                            qDebug() << "parent pointer instead of stepparent pointer in nb_purge function | ";
                                        } else {
                                            qDebug() << "missing stepparent pointer in nb_purge function | ";
                                        }
                                    }
                                }
                                (children->children).Clear();
                                //get rid of step parents
                                for(parents=(children->stepparents).PeekInit();parents!=NULL;parents=(children->stepparents).PeekNext()){
                                    if(parents!=NULL){
                                        //  //DMSG(8,"testline 3 \n");
                                        //if(parents->N_addr!=nb->N_addr){
                                        if(parents->N_addr != nb->N_addr){
                                            //if(parents->children!=nb->children){
                                            if((parents->children).FindObject(children->N_addr)){
                                                (parents->children).RemoveCurrent();
                                            } else {
                                                qDebug() << "missing child link in nb_purge function | ";
                                            }
                                            // }
                                        }
                                    }
                                }
                                (children->stepparents).Clear();
                                delete children;
                                //free(children);
                            }
                        }
                    }
                }
                (nb->children).Clear();
                if((nb->parents).IsEmpty()){ // checking to see if node has parents
                    if(nb->N_status!=LOST_LINKv4){ // if is not a lost link hold it for a bit then will remove later
                        nbold=nb;
                        nbfree=1;
                    }
                }
                else{
                    nb->hop=2; // is now a two hop neighbor
                }
                NbrTuple *mprtuple;
                if((mprtuple = mprSelectorList.FindObject(nb->N_addr))){
                    mprSelectorList.RemoveCurrent();
                    delete mprtuple;

                    updateSmfForwardingInfo = true;  //send updated mpr selector list to send pipe if open
                    //free(mprtuple);


                }
            }
            else { // is a valid one hop neighbor check its children
                //check to see if children are missing
                for(children=(nb->children).PeekInit();children!=NULL;children=(nb->children).PeekNext()){
                    if(children!=NULL){
                        if((nb->children).checkCurrent()){ // check to see if link expired child lost
//                            mprupdate=1;
                            //printCurrentTable(3);
                            ////DMSG(1,"%d's perspective deleating link %d from %d's table \n",myaddress.IPv4HostAddr(),children->N_addr,nb->N_addr);
                            //DMSG(7,"Removing: %s's perspective deleating link ",myaddress.GetHostString());
                            //DMSG(7,"%s ",children->N_addr.GetHostString());
                            //DMSG(7,"from %s's table \n",nb->N_addr.GetHostString());
                            (nb->children).RemoveCurrent();
                            if((children->parents).FindObject(nb->N_addr)) // child is lost
                                (children->parents).RemoveCurrent();
                            if((children->stepparents).FindObject(nb->N_addr))
                                (children->stepparents).RemoveCurrent(); // (ah ha found you vindication!)
                            ////DMSG(1,"is empty? %d hop value %d",children->parents.IsEmpty(),children->hop);
                            //DMSG(9,"is empty? %d hop value %d",children->parents.IsEmpty(),children->hop);
                            if((children->parents).IsEmpty()){
                                //child is lost only parent
                                if(nbr_2hop_list.FindObject(children->N_addr)){ // may have not been added to two hop table????
                                    nbr_2hop_list.RemoveCurrent();
                                } else {
                                    //DMSG(8,"Warning: while removing two hop link %s which was not in 2 hop neighbor table\n",children->N_addr.GetHostString());
                                }
                                // remove all stepparent links
                                if(!nbr_list.FindObject(children->N_addr)){ //check to see if it was exclusivly a 2 hop neighbor
                                    for(parents=((children->stepparents).PeekInit());parents!=NULL;parents=(children->stepparents).PeekNext()){
                                        if(parents!=NULL){
                                            if(parents->N_addr != nb->N_addr){ //don't remove current parent will be done later
                                                //if(parents->N_addr!=nb->N_addr){ //don't remove current parent will be done later
                                                if((parents->children).FindObject(children->N_addr))
                                                    (parents->children).RemoveCurrent();
                                            }
                                        }
                                    }
                                    (children->stepparents).Clear();
                                    delete children;
                                    //free(children);
                                }
                            }
                        }
                    }
                }
            }
        }
        if(nbfree){
            //remove last of pointers to this object
            for(parents=(nbold->stepparents).PeekInit();parents!=NULL;parents=(nbold->stepparents).PeekNext()){
                if(parents!=NULL){
                    if((parents->children).FindObject(nbold->N_addr))
                        (parents->children).RemoveCurrent();
                }
            }
            (nbold->stepparents).Clear();
            delete nbold;
            //free(nbold);
            nbfree=0;
        }
    }
    if(nbfree){
        //remove last of pointers to this object
        for(parents=(nbold->stepparents).PeekInit();parents!=NULL;parents=(nbold->stepparents).PeekNext()){
            if(parents!=NULL){
                if((parents->children).FindObject(nbold->N_addr))
                    (parents->children).RemoveCurrent();
            }
        }
        (nbold->stepparents).Clear();
        delete nbold;
        //free(nbold);
    }

    // this is only done on the send hello function
//    if(mprupdate)
//        selectmpr();
    //printCurrentTable(3);
    //DMSG(6,"Exit: Nrlolsr::nb_purge()\n");
}
//end nb_purge

void Nrlolsr::dup_purge() {
    //DMSG(6,"Enter: Nrlolsr::dup_purge()\n");
    NbrTuple *tuple;
    bool removeddup=true;
    for(tuple=duplicateTable.PeekInit();tuple!=NULL && removeddup;tuple=duplicateTable.PeekNext()) {
        if((tuple->N_time<InlineGetCurrentTime())){
            //DMSG(7,"Removing duplicate tuple %s from ",tuple->N_addr.GetHostString());
            //DMSG(7,"%s's list at time %f \n",myaddress.IPv4HostAddr(),InlineGetCurrentTime());
            duplicateTable.RemoveCurrent();
            delete tuple;
            //free(tuple);
        }
        else{
            removeddup=false;
        }
    }
    //DMSG(6,"Exit: Nrlolsr::dup_purge()\n");
}
// end dup_purge


// select mprs as outlined in the spec v8
// I recomend that you read and understand the spec and not just my poor explination of what its doing
// the way mprs are seleced: first pick the neighbors which are the only route to some nodes
// they have to be picked unless one hop neighbor has a willingness factor of never in which case the 2 hop
// neighbor should not be in the list.  Then add in all neighbors with a willingness of ALWAYS.  Procede to
// step though the williness factors starting from the most willing picking the node that connects to the most
// uncovered 2 hop neighbors and repeat breaking ties by picking the node connected to the most nodes(covered included).
// If 2 hop neighbors are still uncovered go down and check the next willingness group.
// thats what this code does
void Nrlolsr::selectmpr() {
//    DMSG(6,"Enter: Nrlolsr::selectmpr of node %s with mssn of %d()\n",myaddress.GetHostString(),mssn);
//    printCurrentTable(10);
    int numberOfParents;
    NbrTuple *child, *parent, *newmpr=NULL;
    //printCurrentTable(3);
    //DMSG(8," initializing mpr and incrimenting %s's mssn number which is now %d \n",myaddress.GetHostString(),mssn+1);
    mssn++;
    mssn=mssn % MAXMSSN;
    for(parent=nbr_list.PeekInit();parent!=NULL;parent=nbr_list.PeekNext()){
        if(parent!=NULL){
            if(parent->N_status==MPR_LINKv4)
                parent->N_status=SYM_LINKv4;
            parent->tdegree=0;
            parent->cdegree=0;
        }
    }
    //  DMSG(11," assigining degrees \n");
    //  fflush(stdout);
    for(child=nbr_list.PeekInit();child!=NULL;child=nbr_list.PeekNext()){
        if(child!=NULL){
            if(child->N_status!=SYM_LINKv4 && child->N_status!=MPR_LINKv4){
                numberOfParents=0;
                //DMSG(11,"%s is adding to - ",child->N_addr.GetHostString());
                //fflush(stdout);
                for(parent=(child->parents).PeekInit();parent!=NULL;parent=(child->parents).PeekNext()){
                    if(parent!=NULL){
                        if(TupleLinkIsUp(parent)){
                            //if((parent->N_status==MPR_LINKv4 || parent->N_status==SYM_LINKv4) && parent->N_willingness!=WILL_NEVER && parent->N_macstatus!=LINK_DOWN){
                            //DMSG(11,"%s %d:",parent->N_addr.GetHostString(),parent->cdegree+1);
                            //fflush(stdout);
                            numberOfParents++;
                            parent->tdegree++;
                            parent->cdegree++;
                        }
                    }
                }
                //DMSG(11,"\n");
                if(numberOfParents==1){// parent node must be selected at mpr
                    parent=(child->parents).PeekInit();
                    if(parent->N_willingness!=WILL_NEVER){
                        //DMSG(8,"parent node %s must be selected as mpr\n",parent->N_addr.GetHostString());
                        makempr(parent);
                    }
                }
            }
        }
        //DMSG(11 ,"\n");
        //fflush(stdout);
    }

    //assigining degrees for 2 hop neighbors
    for(child=nbr_2hop_list.PeekInit();child!=NULL;child=nbr_2hop_list.PeekNext()){
        if(child!=NULL){
            if(child->hop==2){
                if(!nbr_list.FindObject(child->N_addr)){
                    numberOfParents=0;
                    //DMSG(11,"%s is adding to - ",child->N_addr.GetHostString());
                    //fflush(stdout);
                    for(parent=(child->parents).PeekInit();parent!=NULL;parent=(child->parents).PeekNext()){
                        if(parent!=NULL){
                            if(TupleLinkIsUp(parent)){
                                //if((parent->N_status==MPR_LINKv4 || parent->N_status==SYM_LINKv4) && parent->N_willingness!=WILL_NEVER && parent->N_macstatus!=LINK_DOWN){
                                //DMSG(11,"%s %d:",parent->N_addr.GetHostString(),parent->cdegree+1);
                                //fflush(stdout);
                                numberOfParents++;
                                parent->tdegree++;
                                parent->cdegree++;
                            }
                        }
                    }
                    //DMSG(11,"\n");
                    if(numberOfParents==1){// parent node must be selected at mpr
                        parent=(child->parents).PeekInit();
                        if(parent->N_willingness!=WILL_NEVER){
                            makempr(parent);
                        }
                    }
                }
            }
        }
        //DMSG(11 ,"\n");
        //fflush(stdout);
    }
    //DMSG(9,"selecting biggest degrees \n");
    //fflush(stdout);
    //for printing out degrees
//    if(olsrDebugValue>=10){
//        for(parent=nbr_list.PeekInit();parent!=NULL;parent=nbr_list.PeekNext()){
//            DMSG(10,"%s has degree %d\n",parent->N_addr.GetHostString(),parent->cdegree);
//        }
//    }

    for(parent=nbr_list.PeekInit();parent!=NULL;parent=nbr_list.PeekNext()){
        if(parent->N_willingness == WILL_ALWAYS && parent->N_status!=LINK_DOWN){
            makempr(parent);
        }
    }
    // go through and select highest willingness nodes with the biggest degree
    for(int currentwillingness = 6;currentwillingness>0;currentwillingness--){
        int highestdegree=1;
        while(highestdegree){
            highestdegree=0;
            for(parent=nbr_list.PeekInit();parent!=NULL;parent=nbr_list.PeekNext()){
                if(parent->N_willingness == currentwillingness){
                    if((int)(parent->cdegree)>(int)highestdegree){
//                        DMSG(10,"%s is new highest at %d count \n",parent->N_addr.GetHostString(),parent->cdegree);
                        highestdegree=parent->cdegree;
                        newmpr=parent;
                    }
                }
            }
//            DMSG(10,"%d is highest degree",highestdegree);
            if(highestdegree)
                makempr(newmpr);
        }
    }
    //DMSG(6,"Enter: Nrlolsr::selectmpr()\n");
}

bool Nrlolsr::TupleLinkIsUp(NbrTuple* tuple){ //returns true if tuple state indicates its a true one hop neighbor which can forward
    return ((tuple->N_status==MPR_LINKv4 || tuple->N_status==SYM_LINKv4)
            && tuple->N_willingness!=WILL_NEVER
            && tuple->N_macstatus!=LINK_DOWN
            && tuple->hop==1);
}

// this makes a node an mpr and updates the current nodal degree of all the other one hop nodes
void Nrlolsr::makempr(NbrTuple *parent) { // updates the current degrees with the parent node selected
    //DMSG(6,"Enter: Nrlolsr::makempr(*parent %s)\n",parent->N_addr.GetHostString());
    NbrTuple *child, *stepparent;
    if(parent->N_status!=MPR_LINKv4){ // check to see if its an mpr already
        parent->N_status=MPR_LINKv4;
        //DMSG(8,"%s is new mpr of ",parent->N_addr.GetHostString());
        //DMSG(8,"%s \n",myaddress.GetHostString());
        for(child=(parent->children).PeekInit();child!=NULL;child=(parent->children).PeekNext()){
            if(child!=NULL){
                //DMSG(9,"%d hop of %s :",child->hop,child->N_addr.GetHostString());
                if((child->hop==2) || (child->N_status!=SYM_LINKv4 && child->N_status!=MPR_LINKv4)){
                    for(stepparent=(child->parents).PeekInit();stepparent!=NULL;stepparent=(child->parents).PeekNext()){
                        if(stepparent!=NULL){
                            stepparent->cdegree--;
                        }
                    }
                }
            }
        }
    }
    //DMSG(6,"Exit: Nrlolsr::makempr(*parent %s)\n",parent->N_addr.GetHostString());
}
