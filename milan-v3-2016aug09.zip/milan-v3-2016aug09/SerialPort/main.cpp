#include <QCoreApplication>
#include "serialporthandler.h"
#include <QStringList>
#include <QDebug>
#include <QFile>

#include "nrlolsr.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int argumentCount = QCoreApplication::arguments().size();
    QStringList argumentList = QCoreApplication::arguments();

    int ifIndex;

    if (argumentCount <= 2) {
        qDebug() << ("Use with parameters <interfacename> <myUniqueAddress>") << endl;
        return 1;
    }


    QString portName = argumentList.at(1);
    unsigned int myAddress = argumentList.at(2).toInt();

    QSerialPort serialPort;
    ifIndex = 1; //SerialPort
    if (portName != "UDP")
        serialPort.setPortName(portName);
    else
        ifIndex = 2; // UdpSocket

    Nrlolsr olsrHandler(myAddress, &serialPort);

//    olsrHandler.serialPortHandler(&serialPort);

    olsrHandler.Start(ifIndex);
//    olsrHandler.Test();


    return a.exec();
}


