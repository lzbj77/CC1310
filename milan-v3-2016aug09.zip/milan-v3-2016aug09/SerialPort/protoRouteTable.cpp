
#include "protoRouteTable.h"
#include <QDebug>

ProtoRouteTable::ProtoRouteTable()
{
    routes.clear();
    routes.resize(0);
}

ProtoRouteTable::~ProtoRouteTable()
{
    Destroy();
}

void ProtoRouteTable::Destroy()
{
    // Get rid of entries contained in list.
    routes.clear();
    routes.squeeze();
}  // end ProtoRouteTable::Destroy()


bool ProtoRouteTable::SetRoute(const UINT32&  dst,
                               const UINT32&  gw,
                               unsigned int         ifIndex,
                               int                  metric)
{
    qDebug() << "SetRoute(): routes total: " << routes.size() << endl;
    Entry* entry = GetEntry(dst);
    // (TBD) allow for multiple routes to same dst/mask ???
    if (NULL == entry)
        entry = CreateEntry(dst, ifIndex);
    if (entry)
    {
        entry->gateway = gw;
        entry->iface_index = ifIndex;
        entry->metric = metric;
        return true;
    }
    else
    {
        qDebug() << "ProtoRouteTable::SetRoute() error creating entry\n";
        qDebug() << "params: " << dst << ' ' << gw << ' ' << ifIndex << ' ' << metric << endl;
        return false;
    }
    qDebug() << "Quit: SetRoute()";
}  // end ProtoRouteTable::SetRoute()

//bool ProtoRouteTable::FindRoute(const UINT32& dst,
////                                unsigned int        prefixSize,
//                                UINT32&       gw,
////                                unsigned int&       ifIndex,
//                                int&                metric)
//{
//    Entry* entry = FindRouteEntry(dst/*, prefixSize*/);
//    if (entry)
//    {
//        gw = entry->gateway;
////        ifIndex = entry->iface_index;
//        metric = entry->metric;
//        return true;
//    }
//    else
//    {
//        return false;
//    }
//}  // end ProtoRouteTable::FindRoute()

bool ProtoRouteTable::DeleteRoute(const UINT32& dst,
                                  const UINT32 gw)
{
    qDebug() << "DeleteRoute(): routes total: " << routes.size() << endl;
    Entry* entry = GetEntry(dst);
    if (entry)
    {
        if (entry->gateway != gw)
        {
            //		DMSG(0, "ProtoRouteTable::DeleteRoute() non-matching gateway addr\n");
            return false;
        }

        DeleteEntry(entry);
        qDebug() << "Quit: DeleteRoute() true";
        return true;
    }
    else
    {
        qDebug() << "Quit: DeleteRoute() false";
        return false;
    }
}  // end ProtoRouteTable::DeleteRoute()

ProtoRouteTable::Entry* ProtoRouteTable::CreateEntry(const UINT32& dstAddr,
                                                     unsigned int        ifIndex)
{
    qDebug() << "CreateEntry(): routes total: " << routes.size() << ' ' << routes.count();
    Entry* entry = new Entry(dstAddr, ifIndex);
    if (NULL == entry)
    {
//        DMSG(0, "ProtoRouteTable::CreateEntry() memory allocation error: %s\n",
//                GetErrorString());
        delete entry;
        return NULL;
    }
    // Bind the item and the entry
    foreach (const Entry* route, routes)
    {
        if (route->destination == entry->destination)
        {
            qDebug() << "ProtoRouteTable::CreateEntry() equivalent entry already exists?\n";
            delete entry;
            return NULL;
        }
    }
    routes.append(entry);
    qDebug() << "Quit: CreateEntry()";
    return entry;

}  // end ProtoRouteTable::CreateEntry()

ProtoRouteTable::Entry* ProtoRouteTable::GetEntry(const UINT32& dstAddr) const
{
    qDebug() << "GetEntry(): routes total: " << routes.size();
    if (!routes.isEmpty())
    {
        for (int i = 0; i < routes.size(); i++)
        {
            if (routes.at(i)->destination == dstAddr)
            {
                qDebug() << "Quit: GetEntry() " << i << ' ' << dstAddr;
                return routes[i];
            }
        }
        qDebug() << "ProtoRouteTable::GetEntry: Entry with addr " << dstAddr << " is not found!\n";
    }

    qDebug() << "Quit: GetEntry() NULL";
    return NULL;
}  // end ProtoRouteTable::GetEntry()

void ProtoRouteTable::DeleteEntry(ProtoRouteTable::Entry* entry)
{
    qDebug() << "DeleteEntry(): routes total: " << routes.size();
    if (routes.isEmpty())
    {
        qDebug() << "DeleteEntry(): table is already empty!\n";
        return;
    }
    if (NULL == entry) return;
//    Entry* entryFound = static_cast<Entry*>(routes.Find((char*)entry->GetDestination(), ADDRESS_SIZE));
    for (int i = 0; i < routes.size(); i++)
    {
        if (routes.at(i)->destination == entry->destination)
        {
            routes.removeAt(i);
            delete entry;
            qDebug() << "Quit: DeleteEntry()";
            return;
        }
    }

    qDebug() << "ProtoRouteTable::DeleteEntry() invalid entry: " << entry->destination << endl;

}  // end ProtoRouteTable::DeleteEntry()

ProtoRouteTable::Entry::Entry()
    : iface_index(0), metric(-1)
{
    destination = INVALID_ADDRESS;
    gateway = INVALID_ADDRESS;
}

ProtoRouteTable::Entry::~Entry()
{
}

ProtoRouteTable::Entry::Entry(const UINT32& dstAddr, unsigned int ifIndex)
 : iface_index(ifIndex), metric(-1)
{
    destination = dstAddr;
    gateway = INVALID_ADDRESS;
}

void ProtoRouteTable::Entry::Init(const UINT32& dstAddr)
{
    destination = dstAddr;
    gateway = INVALID_ADDRESS;
    iface_index = 0;
    metric = -1;
}  // end ProtoRouteTable::Entry::Init()
