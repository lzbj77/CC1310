#ifndef _PROTO_ROUTE_TABLE
#define _PROTO_ROUTE_TABLE

//#define QT_STRICT_ITERATORS

#define INVALID_ADDRESS 0x00000000
#define ADDRESS_SIZE 32
//#include "UINT32.h"
//#include "protoTree.h"
#include "QVector"
/*!
Class based on the ProtoTree Patricia tree to
store routing table information. Uses the
ProtoAddress class to store network routing
addresses.  It's a pretty dumbed-down routing
table at the moment, but may be enhanced in
the future.  Example use of the ProtoTree.

Notes:

1) Only one entry per destination/prefixLen is currently allowed.
  (Only one route per unique destination is maintained)
  (We may support multiple routes per dest in the future)

2) (ifIndex == 0) and (metric < 0) are "wildcards"
*/
typedef unsigned int UINT32 ;

class ProtoRouteTable
{
   public:
       ProtoRouteTable();
       ~ProtoRouteTable();

       bool Init() {Destroy(); return true;}
       void Destroy();

//        bool IsEmpty() {return (routes.isEmpty() && !default_entry.IsValid());}

       // For "GetRoute()" to work there _must_ be
       // an exact match (dst and prefixLen) route entry in the table.
//        bool GetRoute(const UINT32&   dst,        // input
////                      unsigned int          prefixLen,  // input
//                      UINT32&         gw,         // output
////                      unsigned int&         ifIndex,    // output
//                      int&                  metric);    // output

       bool SetRoute(const UINT32&   dst,
//                      unsigned int          maskLen,
                     const UINT32&   gw,
                     unsigned int          ifIndex = 0,
                     int                   metric = -1);

       // Note gateway is optional here
       bool DeleteRoute(const UINT32 &dst,
//                         unsigned int           maskLen,
                        const UINT32 gw = INVALID_ADDRESS);

       // Find the "best" route to the given destination
       // (Finds route entry with longest matching prefix (or default))
//        bool FindRoute(const UINT32&  dstAddr,
////                       unsigned int         prefixLen,
//                       UINT32&        gwAddr,
////                       unsigned int&        ifIndex,
//                       int&                 metric);

       class Entry
       {
           friend class ProtoRouteTable;

           public:
               bool IsValid() const {return (destination);}
//                void SetGateway(const UINT32& gwAddr) {gateway = gwAddr;}
//                void ClearGateway() {gateway = INVALID_ADDRESS ;} //Not existing address
//                void SetInterface(unsigned int ifaceIndex) {iface_index = ifaceIndex;}
//                void ClearInterface() {iface_index = 0;}
//                void SetMetric(int value) {metric = value;}

               const UINT32& GetDestination() const {return destination;}
//                const UINT32& GetGateway() const {return gateway;}
//                unsigned int GetInterfaceIndex() const {return iface_index;}
               int GetMetric() const {return metric;}

               void Clear()
               {
                   destination = INVALID_ADDRESS;
//                    prefix_size = 0;
                   gateway = INVALID_ADDRESS;
                   iface_index = 0;
                   metric = -1;
               }

           private:
               Entry();
               Entry(const UINT32& dstAddr, unsigned int ifIndex);
               ~Entry();

               void Init(const UINT32& dstAddr/*, unsigned int prefixSize*/);

               UINT32        destination;
//                unsigned            prefix_size;  // in bits
               UINT32        gateway;
               unsigned int        iface_index;
               int                 metric;
       };  // end class ProtoRouteTable::Entry

       ProtoRouteTable::Entry* CreateEntry(const UINT32& dstAddr,
                                           unsigned int          ifIndex);

       // Get entry exactly matching dstAddr/prefixLen
       ProtoRouteTable::Entry* GetEntry(const UINT32& dstAddr) const;

       // Find best matching route entry
//        ProtoRouteTable::Entry* FindRouteEntry(const UINT32& dstAddr/*,
//                                               unsigned int          prefixLen*/) const;

       void DeleteEntry(ProtoRouteTable::Entry* entry);

   private:
       QVector<Entry*>  routes;
       Entry      default_entry;
};  // end class ProtoRouteTable

#endif // _PROTO_ROUTE_TABLE
