#ifndef NRLOLSR_H
#define NRLOLSR_H

#define OLSRMAXSPF 255.0 //8 bits
#define MAXMSSN 65535
#define INTERFACE_COM 1
#define INTERFACE_UDP 2

#include <QObject>
#include <QTimer>
#include <QThread>

#include "serialporthandler.h"
#include "udpsockethandler.h"
#include "olsr_packet_types.h"
#include "math.h"
#include "nbr_queue.h"
#include "protoRouteTable.h"
#include "timermanager.h"


inline double UniformRand(double max){
  return (max * ((double)rand() / (double)RAND_MAX));
}

inline int GetLittleTime()
{
    struct timeval tv;
    SystemTime(tv);
    double current_time = ((double)tv.tv_usec)/1.0e06;
    int hacknumber=(int)current_time;
    current_time-=(double)hacknumber;
    current_time=1.0e06*current_time;
    return (int)current_time;
}


class Nrlolsr : public QObject
{
    Q_OBJECT
public:
    explicit Nrlolsr(unsigned int myAddr, QSerialPort *serialPort = 0, QObject *parent = 0);
    ~Nrlolsr();

    void Test();

    bool Start(int ifIndex);

    enum FloodingType {SIMPLE, SMPR, NSMPR, NOTSYM, ECDS, MPRCDS};

signals:

    void RoutingPacketArrived(QByteArray &packet);
    void StartTimer(double randValue);
    void StopTimer();

public slots:

    void GetRoutingPacket(QByteArray &packet);

private slots:

    bool OnHelloTimeout(/*ProtoTimer &theTimer*/);

//    void HandlePrintTimer(QTimer &timer);

//    bool OnDelayedForwardTimeout(/*ProtoTimer &theTimer*/);//event which sends out messages saved for forwarding

protected:

    enum NodeLinkState {LINK_DEFAULT, LINK_UP, LINK_DOWN};

    unsigned int   interfaceIndex;

    UINT32 invalidAddress;

    int a8packedmessages;

    double alpha;          //decides rate of change smaller number allow for faster rates of neighbor chages between 0-1
    double T_up;          //neighbor threshold 0-1
    double T_down;        //neighbor threshold used with time outs and time out timer 0-1 less than T_up


    UINT16         seqno;  //Message Sequence Number
    UINT16         pseqno; //Packet Sequence Number
    int            mssn;   //mpr selector list number

    int            localWillingness;

    double         Hello_Interval;
    UINT8          Mantissa_Hello_Interval;
//    UINT8          Mantissa_Hello_Hold_Interval;
    double         Hello_Timeout_Factor;
    double         Hello_Jitter; //% of Hello_Interval

    double         Neighb_Hold_Time;
    double         D_Hold_Time;

    NBRQueue       mprSelectorList;  //list of mpr selector nodes
    NBRQueue       nbr_list;         //list of neighbors
    NBRQueue       nbr_2hop_list;    //list of 2 hop neighbors
    NBRQueue       duplicateTable;   //list of recently recieved packets

    NBRQueue       routeTable;       //list of routes
    NBRQueue       oldRouteTable;    //temp list of routes
    NBRQueue       extraQueue;       //extra queue to use

    NBRQueue       routeNeighborSet; //list used to temporary store the topology tuples (links) which  were used in the route calculation

    NBRQueue       nbr_list_old_for_hello;     //only used for when tcSlowDown is set to true stores old neighbor table when last hello was recieved;



//    ProtoRouteTable llToGlobal;      //mapping of link local ipv6 addresses to global ipv6 addresses
    ProtoRouteTable realRouteTable;

private:

    TimerManager *myTimerMgr;

    SerialPortHandler serialPortHandler;\
    UdpSocketHandler udpSocketHandler;

    QThread *newThread;






    void nb_purge();
    void dup_purge();
    bool SendRoutingData(QByteArray &data);

//    QTimer watchdog_timer;

    void selectmpr();
    void makempr(NbrTuple *parent);
    bool TupleLinkIsUp(NbrTuple *tuple);

    bool SendHello();
    bool sendHelloTimerOn;

//    QTimer delayed_forward_timer;

    void DelayedForward(OlsrMessage *forwardmessage);//used to jitter forwarding of messages


//    void SendForwardingInfo(); //generic function which sends forwarding info dependant on which forwarding mode olsris in

    bool NeighborsStableForHello(); //returns true if neighbor table has not changed since last time hello message was recieved

    int update_nbr(UINT32 id,int status/*,UINT8 spfValue,UINT8 minmaxValue*/);
    int update_nbr(UINT32 id,int status/*,UINT8 spfValue, UINT8 minmaxValue*/, UINT8 Vtime,UINT8 willingness);
    void update_2hop_nbr(UINT32 onehop_addr,UINT32 twohop_addr);
    void update_2hop_nbrExtra(UINT32 onehop_addr,UINT32 twohop_addr,unsigned long nodedegree);// only use for manet ospf extisions
    void remove_2hop_link(UINT32 oneaddr,UINT32 twoaddr);

    void update_mprselector(UINT32 id, int status);

    int IsDuplicate(UINT32 addr,UINT16 dseqno);
    void addDuplicate(UINT32 dupaddr, UINT16 dseqno);

    void makeNewRoutingTable();

    void printCurrentTable(/*int debuglvl*/); //prints neighbor table
    void printRoutingTable(/*int debuglvl*/); //prints routing table

    UINT8 doubletomantissa(double timeinseconds);
    double mantissatodouble(UINT8 mantissatime);



    FloodingType floodingType;

    bool updateSmfForwardingInfo; //set to true if the forwarding information needs to be changed




    UINT32 myaddress;
//    UdpSocketHandler udpSocketHandler;

    OlsrPacket olsrpacket2forward;
};

#endif // NRLOLSR_H
