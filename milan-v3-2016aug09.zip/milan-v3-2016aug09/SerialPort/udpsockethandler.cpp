#include "udpsockethandler.h"

UdpSocketHandler::UdpSocketHandler(QObject *parent) : QObject(parent)
{
    m_socket = new QUdpSocket(this);
    m_socket->bind(698);

    connect(m_socket, SIGNAL(readyRead()), this, SLOT(ReadData()));
}

UdpSocketHandler::~UdpSocketHandler()
{
    m_socket->disconnectFromHost();
    m_socket->close();
}

void UdpSocketHandler::ReadData()
{
    // when data comes in
    QByteArray buffer;
    buffer.resize(m_socket->pendingDatagramSize());

    QHostAddress sender;
    quint16 senderPort;


    // Receives a datagram no larger than maxSize bytes and stores it in data.
    // The sender's host address and port is stored in *address and *port
    // (unless the pointers are 0).

    m_socket->readDatagram(buffer.data(), buffer.size(),
                         &sender, &senderPort);

    PrintPacket(sender, senderPort, buffer);

    if(true)                                // NEED A CONDITION, SEPARATING ROUTING PACKETS FROM THE OTHERS
        emit RoutingPacketArrived(buffer);
}

bool UdpSocketHandler::SendData(const QByteArray &data)
{
    m_writeData = data;

    qint64 bytesWritten = m_socket->writeDatagram(m_writeData, QHostAddress::Broadcast, 698);

    if (bytesWritten == -1) {
        qDebug() << QObject::tr("Failed to write the data to UDP port 698, error: %1").arg(m_socket->errorString()) << endl;
        return false;
    } else if (bytesWritten != m_writeData.size()) {
        qDebug() << QObject::tr("Failed to write all the data to UDP port 698, error: %1").arg(m_socket->errorString()) << endl;
        return false;
    }

//    m_socket->writeDatagram(data, QHostAddress::Broadcast, 698);
    qDebug() << "---------------\r\nSuccessfully sent data:\r\n" << data << "\r\n-----------\r\n";
    return true;
}


void UdpSocketHandler::PrintPacket(QHostAddress &address, quint16 port, QByteArray &data)
{
    qDebug() << "---------------\r\nSuccessfully recieved data \r\n";
    qDebug() << "Message from: " << address.toString();
    qDebug() << "Message port: " << port;
    qDebug() << "Message: " << data << "\r\n-------------------\r\n";
}
